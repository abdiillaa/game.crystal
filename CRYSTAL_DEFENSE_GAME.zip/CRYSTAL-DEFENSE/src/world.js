import { CONFIG } from './config.js';
export class WorldMap {
        constructor() {
            this.width = CONFIG.WORLD_WIDTH;
            this.height = CONFIG.WORLD_HEIGHT;
            this.obstacles = [];
            this.decals = [];
            this.cracks = [];
            this.spawnPortals = [
                { x: 180, y: 180 },
                { x: 1200, y: 140 },
                { x: 2220, y: 180 },
                { x: 2260, y: 1200 },
                { x: 2220, y: 2220 },
                { x: 1200, y: 2260 },
                { x: 180, y: 2220 },
                { x: 140, y: 1200 }
            ];
            this.buildEnvironment();
        }

        buildEnvironment() {
            // Symmetrical tactical urban ruins around the central plaza (1200, 1200)
            this.obstacles = [
                // Inner defensive bunkers & military crates (leave clear firing lanes)
                { x: 820, y: 840, w: 130, h: 45, type: 'wall', label: 'BUNKER NW' },
                { x: 820, y: 885, w: 45, h: 90, type: 'wall' },

                { x: 1450, y: 840, w: 130, h: 45, type: 'wall', label: 'BUNKER NE' },
                { x: 1535, y: 885, w: 45, h: 90, type: 'wall' },

                { x: 820, y: 1515, w: 130, h: 45, type: 'wall', label: 'BUNKER SW' },
                { x: 820, y: 1425, w: 45, h: 90, type: 'wall' },

                { x: 1450, y: 1515, w: 130, h: 45, type: 'wall', label: 'BUNKER SE' },
                { x: 1535, y: 1425, w: 45, h: 90, type: 'wall' },

                // Outer ruined city building blocks
                { x: 420, y: 420, w: 220, h: 140, type: 'building', label: 'SECTOR A-1' },
                { x: 1760, y: 420, w: 220, h: 140, type: 'building', label: 'SECTOR B-1' },
                { x: 420, y: 1840, w: 220, h: 140, type: 'building', label: 'SECTOR C-4' },
                { x: 1760, y: 1840, w: 220, h: 140, type: 'building', label: 'SECTOR D-4' },

                // Military supply crates & wrecked APCs
                { x: 1150, y: 690, w: 100, h: 48, type: 'crate' },
                { x: 1150, y: 1660, w: 100, h: 48, type: 'crate' },
                { x: 690, y: 1150, w: 48, h: 100, type: 'crate' },
                { x: 1660, y: 1150, w: 48, h: 100, type: 'crate' },

                // Ruined street barriers
                { x: 480, y: 1080, w: 70, h: 220, type: 'wall' },
                { x: 1850, y: 1080, w: 70, h: 220, type: 'wall' },
                { x: 1080, y: 360, w: 240, h: 65, type: 'wall' },
                { x: 1080, y: 1975, w: 240, h: 65, type: 'wall' }
            ];

            // Generate procedural asphalt cracks and scorch craters
            for (let i = 0; i < 45; i++) {
                const cx = 160 + Math.random() * (this.width - 320);
                const cy = 160 + Math.random() * (this.height - 320);
                const points = [];
                let px = cx, py = cy;
                const segs = 4 + Math.floor(Math.random() * 5);
                for (let s = 0; s < segs; s++) {
                    px += (Math.random() - 0.5) * 90;
                    py += (Math.random() - 0.5) * 90;
                    points.push({ x: px, y: py });
                }
                this.cracks.push({ x: cx, y: cy, points, radius: 15 + Math.random() * 25 });
            }
        }

        addBloodDecal(x, y, color = 'rgba(153, 27, 27, 0.45)', radius = 22) {
            this.decals.push({ x, y, color, radius, createdAt: performance.now() });
            if (this.decals.length > 140) {
                this.decals.shift();
            }
        }

        draw(ctx, cam) {
            const startX = Math.floor(cam.x / 120) * 120;
            const startY = Math.floor(cam.y / 120) * 120;

            // 1. Dark Asphalt Base
            ctx.fillStyle = '#080B11';
            ctx.fillRect(cam.x, cam.y, cam.width, cam.height);

            // 2. Tactical Urban Road Grid & Plaza Markings
            ctx.strokeStyle = 'rgba(30, 41, 59, 0.55)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            for (let x = startX; x < cam.x + cam.width + 120; x += 120) {
                ctx.moveTo(x, cam.y);
                ctx.lineTo(x, cam.y + cam.height);
            }
            for (let y = startY; y < cam.y + cam.height + 120; y += 120) {
                ctx.moveTo(cam.x, y);
                ctx.lineTo(cam.x + cam.width, y);
            }
            ctx.stroke();

            // Main intersecting avenues leading to Crystal Plaza
            ctx.fillStyle = 'rgba(15, 23, 42, 0.65)';
            ctx.fillRect(1040, 0, 320, this.height);
            ctx.fillRect(0, 1040, this.width, 320);

            // Yellow hazard road stripes
            ctx.strokeStyle = 'rgba(245, 158, 11, 0.22)';
            ctx.setLineDash([28, 24]);
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(1200, 0); ctx.lineTo(1200, this.height);
            ctx.moveTo(0, 1200); ctx.lineTo(this.width, 1200);
            ctx.stroke();
            ctx.setLineDash([]);

            // Central Crystal Defense Sanctuary Rings
            ctx.save();
            ctx.translate(CONFIG.CRYSTAL_X, CONFIG.CRYSTAL_Y);
            ctx.strokeStyle = 'rgba(0, 240, 255, 0.16)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, 260, 0, Math.PI * 2);
            ctx.stroke();
            ctx.strokeStyle = 'rgba(168, 85, 247, 0.12)';
            ctx.beginPath();
            ctx.arc(0, 0, 165, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();

            // 3. Asphalt Cracks & Blast Craters
            for (const c of this.cracks) {
                if (c.x < cam.x - 150 || c.x > cam.x + cam.width + 150 ||
                    c.y < cam.y - 150 || c.y > cam.y + cam.height + 150) continue;

                ctx.fillStyle = 'rgba(4, 6, 10, 0.7)';
                ctx.beginPath();
                ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = 'rgba(2, 4, 8, 0.85)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(c.x, c.y);
                for (const pt of c.points) ctx.lineTo(pt.x, pt.y);
                ctx.stroke();
            }

            // 4. Blood & Scorch Decals
            for (const d of this.decals) {
                if (d.x < cam.x - 60 || d.x > cam.x + cam.width + 60 ||
                    d.y < cam.y - 60 || d.y > cam.y + cam.height + 60) continue;
                ctx.fillStyle = d.color;
                ctx.beginPath();
                ctx.arc(d.x, d.y, d.radius, 0, Math.PI * 2);
                ctx.fill();
            }

            // 5. Perimeter Spawn Portals
            const pulse = 0.75 + Math.sin(performance.now() * 0.004) * 0.25;
            for (const sp of this.spawnPortals) {
                const grad = ctx.createRadialGradient(sp.x, sp.y, 6, sp.x, sp.y, 48);
                grad.addColorStop(0, `rgba(239, 68, 68, ${0.45 * pulse})`);
                grad.addColorStop(0.6, `rgba(168, 85, 247, ${0.2 * pulse})`);
                grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
                ctx.fillStyle = grad;
                ctx.beginPath();
                ctx.arc(sp.x, sp.y, 48, 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = 'rgba(239, 68, 68, 0.5)';
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.arc(sp.x, sp.y, 26, 0, Math.PI * 2);
                ctx.stroke();
            }

            // 6. World Boundary Laser Fence
            ctx.strokeStyle = '#EF4444';
            ctx.lineWidth = 6;
            ctx.strokeRect(4, 4, this.width - 8, this.height - 8);
        }

        drawObstacles(ctx, cam) {
            for (const ob of this.obstacles) {
                if (ob.x + ob.w < cam.x - 40 || ob.x > cam.x + cam.width + 40 ||
                    ob.y + ob.h < cam.y - 40 || ob.y > cam.y + cam.height + 40) continue;

                // 3D Drop Shadow
                ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
                ctx.fillRect(ob.x + 8, ob.y + 10, ob.w, ob.h);

                if (ob.type === 'building') {
                    ctx.fillStyle = '#111827';
                    ctx.fillRect(ob.x, ob.y, ob.w, ob.h);
                    ctx.strokeStyle = '#334155';
                    ctx.lineWidth = 3;
                    ctx.strokeRect(ob.x, ob.y, ob.w, ob.h);

                    // Roof structural ribs
                    ctx.fillStyle = '#1E293B';
                    ctx.fillRect(ob.x + 12, ob.y + 12, ob.w - 24, ob.h - 24);
                    if (ob.label) {
                        ctx.fillStyle = 'rgba(148, 163, 184, 0.35)';
                        ctx.font = 'bold 12px Orbitron';
                        ctx.fillText(ob.label, ob.x + 18, ob.y + 32);
                    }
                } else if (ob.type === 'crate') {
                    ctx.fillStyle = '#365314';
                    ctx.fillRect(ob.x, ob.y, ob.w, ob.h);
                    ctx.strokeStyle = '#84CC16';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(ob.x, ob.y, ob.w, ob.h);

                    // Military crate cross bracing
                    ctx.strokeStyle = 'rgba(132, 204, 22, 0.35)';
                    ctx.beginPath();
                    ctx.moveTo(ob.x, ob.y); ctx.lineTo(ob.x + ob.w, ob.y + ob.h);
                    ctx.moveTo(ob.x + ob.w, ob.y); ctx.lineTo(ob.x, ob.y + ob.h);
                    ctx.stroke();
                } else {
                    // Reinforced Concrete & Metal Barricade Wall
                    ctx.fillStyle = '#1E293B';
                    ctx.fillRect(ob.x, ob.y, ob.w, ob.h);
                    ctx.strokeStyle = '#00F0FF';
                    ctx.lineWidth = 1.5;
                    ctx.strokeRect(ob.x, ob.y, ob.w, ob.h);

                    // Hazard stripes on top edge
                    ctx.fillStyle = 'rgba(0, 240, 255, 0.15)';
                    ctx.fillRect(ob.x + 4, ob.y + 4, ob.w - 8, 6);
                }
            }
        }
    }
