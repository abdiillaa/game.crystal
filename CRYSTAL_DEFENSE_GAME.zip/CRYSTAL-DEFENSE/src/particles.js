export class ParticleManager {
        constructor() {
            this.particles = [];
            this.texts = [];
        }

        spawnBurst(x, y, color, count = 8, maxSpeed = 150) {
            for (let i = 0; i < count; i++) {
                const a = Math.random() * Math.PI * 2;
                const sp = 30 + Math.random() * maxSpeed;
                this.particles.push({
                    x, y,
                    vx: Math.cos(a) * sp,
                    vy: Math.sin(a) * sp,
                    radius: 2 + Math.random() * 3.5,
                    color,
                    life: 0.25 + Math.random() * 0.25,
                    maxLife: 0.5
                });
            }
            if (this.particles.length > 320) {
                this.particles.splice(0, this.particles.length - 320);
            }
        }

        spawnExplosion(x, y, color, radius = 80) {
            this.spawnBurst(x, y, color, 24, radius * 2.2);
            this.particles.push({
                x, y, vx: 0, vy: 0,
                radius: 10,
                targetRadius: radius,
                isShockwave: true,
                color,
                life: 0.32,
                maxLife: 0.32
            });
        }

        spawnDamageText(x, y, text, color = '#FFFFFF') {
            this.texts.push({
                x: x + (Math.random() - 0.5) * 16,
                y,
                text: String(text),
                color,
                life: 0.55
            });
            if (this.texts.length > 45) this.texts.shift();
        }

        update(dt) {
            for (let i = this.particles.length - 1; i >= 0; i--) {
                const p = this.particles[i];
                p.life -= dt;
                if (p.life <= 0) {
                    this.particles.splice(i, 1);
                    continue;
                }
                if (p.isShockwave) {
                    const prog = 1 - p.life / p.maxLife;
                    p.radius = 10 + (p.targetRadius - 10) * prog;
                } else {
                    p.x += p.vx * dt;
                    p.y += p.vy * dt;
                    p.vx *= 0.92;
                    p.vy *= 0.92;
                }
            }

            for (let i = this.texts.length - 1; i >= 0; i--) {
                const t = this.texts[i];
                t.life -= dt;
                t.y -= 38 * dt;
                if (t.life <= 0) this.texts.splice(i, 1);
            }
        }

        draw(ctx) {
            for (const p of this.particles) {
                const alpha = Math.max(0, p.life / p.maxLife);
                ctx.save();
                ctx.globalAlpha = alpha;
                if (p.isShockwave) {
                    ctx.strokeStyle = p.color;
                    ctx.lineWidth = 3;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.stroke();
                } else {
                    ctx.fillStyle = p.color;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.restore();
            }

            ctx.font = 'bold 13px "JetBrains Mono", monospace';
            ctx.textAlign = 'center';
            for (const t of this.texts) {
                ctx.fillStyle = t.color;
                ctx.fillText(t.text, t.x, t.y);
            }
        }
    }
