export class CrystalDefenseGame {
        constructor() {
            this.canvas = document.getElementById('gameCanvas');
            this.ctx = this.canvas.getContext('2d');
            this.state = 'MENU'; // MENU | PLAYING | PAUSED | SHOP | OVER
            this.elapsedTime = 0;

            this.audio = new SoundSystem();
            this.save = new SaveManager();
            this.camera = new Camera(window.innerWidth, window.innerHeight);
            this.world = new WorldMap();
            this.crystal = new EnergyCrystal();
            this.player = new Player();
            this.enemies = [];
            this.projectiles = [];
            this.particles = new ParticleManager();
            this.waves = new WaveManager(this);
            this.shop = new ShopManager(this);
            this.ui = new UIManager(this);
            this.input = new InputController(this.canvas, this);

            this.applySavedSettings();
            this.handleResize();
            window.addEventListener('resize', () => this.handleResize());
            this.bindUIButtons();
            this.ui.refreshMainMenuStats();

            // Background ambient entities for the Main Menu preview
            this.spawnMenuPreviewEntities();

            this.lastFrameTime = performance.now();
            requestAnimationFrame((ts) => this.loop(ts));
        }

        handleResize() {
            this.canvas.width = window.innerWidth;
            this.canvas.height = window.innerHeight;
            this.camera.resize(this.canvas.width, this.canvas.height);
        }

        applySavedSettings() {
            const s = this.save.data.settings;
            this.audio.sfxVolume = s.sfxVolume / 100;
            this.audio.musicVolume = s.musicVolume / 100;
            document.getElementById('sliderSfxVol').value = s.sfxVolume;
            document.getElementById('lblSfxVol').textContent = `${s.sfxVolume}%`;
            document.getElementById('sliderMusicVol').value = s.musicVolume;
            document.getElementById('lblMusicVol').textContent = `${s.musicVolume}%`;

            const showTouch = s.touchControls || this.input.isTouchDevice;
            document.getElementById('toggleTouchControls').checked = showTouch;
            document.getElementById('toggleHazardIndicators').checked = s.hazardIndicators;
            this.updateTouchVisibility();
        }

        updateTouchVisibility() {
            const showTouch = document.getElementById('toggleTouchControls').checked;
            const el = document.getElementById('mobileControls');
            if (showTouch && this.state === 'PLAYING') {
                el.classList.remove('hidden');
            } else {
                el.classList.add('hidden');
            }
        }

        spawnMenuPreviewEntities() {
            this.enemies = [];
            for (let i = 0; i < 8; i++) {
                const a = (Math.PI * 2 * i) / 8;
                this.enemies.push(new Enemy('normal', CONFIG.CRYSTAL_X + Math.cos(a) * 380, CONFIG.CRYSTAL_Y + Math.sin(a) * 380, 1));
            }
        }

        startNewGame(startWave = 1) {
            this.audio.resume();
            this.crystal = new EnergyCrystal();
            this.player = new Player();
            this.enemies = [];
            this.projectiles = [];
            this.particles = new ParticleManager();
            this.elapsedTime = 0;

            document.getElementById('mainMenuModal').classList.add('hidden');
            document.getElementById('endGameModal').classList.add('hidden');
            document.getElementById('pauseModal').classList.add('hidden');
            document.getElementById('shopModal').classList.add('hidden');

            const hud = document.getElementById('hudContainer');
            hud.classList.remove('hidden');
            hud.classList.add('flex');

            this.state = 'PLAYING';
            this.updateTouchVisibility();
            this.waves.startWave(startWave);
            this.ui.updateHud();
        }

        continueSavedGame() {
            const snap = this.save.data.activeRun;
            if (!snap) return;
            this.startNewGame(snap.wave || 1);
            this.player.money = snap.money || 0;
            this.player.score = snap.score || 0;
            this.player.kills = snap.kills || 0;
            this.player.hp = snap.playerHp || this.player.maxHp;
            this.player.shield = snap.playerShield || 0;
            if (snap.upgrades) {
                this.player.upgrades = { ...this.player.upgrades, ...snap.upgrades };
            }
            this.crystal.hp = snap.crystalHp || this.crystal.maxHp;
            this.ui.updateHud();
            this.ui.showToast(`Сақталған ойын (${snap.wave}-толқын) жүктелді!`);
        }

        saveSnapshot() {
            this.save.saveActiveRun({
                wave: this.waves.currentWave,
                money: this.player.money,
                score: this.player.score,
                kills: this.player.kills,
                playerHp: this.player.hp,
                playerShield: this.player.shield,
                crystalHp: this.crystal.hp,
                upgrades: { ...this.player.upgrades }
            });
            this.ui.refreshMainMenuStats();
        }

        togglePause() {
            if (this.state === 'PLAYING') {
                this.state = 'PAUSED';
                this.saveSnapshot();
                document.getElementById('pauseModal').classList.remove('hidden');
                document.getElementById('pauseModal').classList.add('flex');
                this.updateTouchVisibility();
            } else if (this.state === 'PAUSED') {
                this.state = 'PLAYING';
                document.getElementById('pauseModal').classList.add('hidden');
                document.getElementById('pauseModal').classList.remove('flex');
                this.updateTouchVisibility();
            }
        }

        toggleShopModal(forceState) {
            const modal = document.getElementById('shopModal');
            const open = typeof forceState === 'boolean' ? forceState : (this.state !== 'SHOP');
            if (open && (this.state === 'PLAYING' || this.state === 'PAUSED')) {
                this.state = 'SHOP';
                document.getElementById('pauseModal').classList.add('hidden');
                this.shop.renderShop();
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                this.updateTouchVisibility();
            } else if (!open && this.state === 'SHOP') {
                this.state = 'PLAYING';
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                this.updateTouchVisibility();
            }
        }

        triggerGameOver(isVictory, reasonText) {
            if (this.state === 'OVER') return;
            this.state = 'OVER';
            this.input.mouse.down = false;
            this.updateTouchVisibility();

            this.save.recordStats(this.waves.currentWave, this.player.score, this.player.kills, isVictory);
            if (!isVictory) {
                this.save.clearActiveRun();
                this.audio.playDefeat();
            } else {
                this.audio.playVictory();
            }
            this.ui.refreshMainMenuStats();

            const modal = document.getElementById('endGameModal');
            const title = document.getElementById('endGameTitle');
            const badge = document.getElementById('endGameBadge');
            const bonusBtn = document.getElementById('btnEndlessBossMode');

            if (isVictory) {
                badge.textContent = 'MISSION ACCOMPLISHED';
                badge.className = 'inline-block px-3 py-1 rounded-full text-xs font-mono-num uppercase tracking-widest mb-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40';
                title.textContent = 'VICTORY!';
                title.className = 'font-display font-black text-3xl sm:text-4xl uppercase tracking-wider text-emerald-400 mb-2';
                bonusBtn.classList.remove('hidden');
            } else {
                badge.textContent = 'MISSION FAILED';
                badge.className = 'inline-block px-3 py-1 rounded-full text-xs font-mono-num uppercase tracking-widest mb-2 bg-red-500/20 text-red-300 border border-red-500/40';
                title.textContent = 'SURVIVAL FAILED';
                title.className = 'font-display font-black text-3xl sm:text-4xl uppercase tracking-wider text-red-500 mb-2';
                bonusBtn.classList.add('hidden');
            }

            document.getElementById('endGameReason').textContent = reasonText;
            document.getElementById('endStatWave').textContent = this.waves.currentWave;
            document.getElementById('endStatKills').textContent = this.player.kills;
            document.getElementById('endStatMoney').textContent = `$${this.player.money}`;
            document.getElementById('endStatScore').textContent = this.player.score;

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        returnToMainMenu() {
            this.state = 'MENU';
            document.getElementById('hudContainer').classList.add('hidden');
            document.getElementById('pauseModal').classList.add('hidden');
            document.getElementById('shopModal').classList.add('hidden');
            document.getElementById('endGameModal').classList.add('hidden');
            document.getElementById('mainMenuModal').classList.remove('hidden');
            this.updateTouchVisibility();
            this.ui.refreshMainMenuStats();
            this.spawnMenuPreviewEntities();
        }

        bindUIButtons() {
            document.getElementById('btnNewGame').addEventListener('click', () => this.startNewGame(1));
            document.getElementById('btnContinueGame').addEventListener('click', () => this.continueSavedGame());

            // Weapon Tabs
            document.querySelectorAll('.weapon-slot-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const idx = Number(btn.getAttribute('data-weapon'));
                    this.player.switchWeapon(idx);
                    this.ui.updateHud();
                });
            });

            // HUD Buttons
            document.getElementById('btnQuickShop').addEventListener('click', () => this.toggleShopModal(true));
            document.getElementById('btnOpenShopHud').addEventListener('click', () => this.toggleShopModal(true));
            document.getElementById('btnSkipWaveWait').addEventListener('click', () => {
                if (this.waves.inIntermission) this.waves.intermissionTimer = 0.05;
            });
            document.getElementById('btnPauseGame').addEventListener('click', () => this.togglePause());

            // Shop Modal Buttons
            document.getElementById('btnCloseShop').addEventListener('click', () => this.toggleShopModal(false));
            document.getElementById('btnShopStartWave').addEventListener('click', () => {
                this.toggleShopModal(false);
                if (this.waves.inIntermission) this.waves.intermissionTimer = 0.05;
            });

            // Pause Modal Buttons
            document.getElementById('btnResumeGame').addEventListener('click', () => this.togglePause());
            document.getElementById('btnPauseShop').addEventListener('click', () => this.toggleShopModal(true));
            document.getElementById('btnPauseSettings').addEventListener('click', () => this.openSettingsModal());
            document.getElementById('btnRestartGame').addEventListener('click', () => this.startNewGame(1));
            document.getElementById('btnPauseToMenu').addEventListener('click', () => this.returnToMainMenu());

            // End Screen Buttons
            document.getElementById('btnEndRestart').addEventListener('click', () => this.startNewGame(1));
            document.getElementById('btnEndlessBossMode').addEventListener('click', () => {
                document.getElementById('endGameModal').classList.add('hidden');
                this.state = 'PLAYING';
                this.waves.startWave(11);
            });
            document.getElementById('btnEndMenu').addEventListener('click', () => this.returnToMainMenu());

            // Settings Modal
            document.getElementById('btnOpenSettings').addEventListener('click', () => this.openSettingsModal());
            document.getElementById('btnCloseSettings').addEventListener('click', () => this.closeSettingsModal());
            document.getElementById('btnSaveSettings').addEventListener('click', () => this.closeSettingsModal());

            document.getElementById('sliderSfxVol').addEventListener('input', (e) => {
                const v = Number(e.target.value);
                document.getElementById('lblSfxVol').textContent = `${v}%`;
                this.audio.sfxVolume = v / 100;
            });
            document.getElementById('sliderMusicVol').addEventListener('input', (e) => {
                const v = Number(e.target.value);
                document.getElementById('lblMusicVol').textContent = `${v}%`;
                this.audio.musicVolume = v / 100;
            });
            document.getElementById('btnToggleFullscreen').addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen().catch(() => {});
                } else {
                    document.exitFullscreen().catch(() => {});
                }
            });

            // Controls & Credits Info Modal
            document.getElementById('btnOpenControls').addEventListener('click', () => this.openInfoModal('controls'));
            document.getElementById('btnOpenCredits').addEventListener('click', () => this.openInfoModal('credits'));
            document.getElementById('btnCloseInfoModal').addEventListener('click', () => {
                document.getElementById('infoModal').classList.add('hidden');
            });
            document.getElementById('btnCloseInfoBottom').addEventListener('click', () => {
                document.getElementById('infoModal').classList.add('hidden');
            });

            // ZIP Archive Download Buttons
            document.getElementById('btnDownloadZipMain').addEventListener('click', () => ProjectZipExporter.downloadFullProjectZip(this));
            document.getElementById('btnHudZip').addEventListener('click', () => ProjectZipExporter.downloadFullProjectZip(this));

            // Automated 20-Test Verification Suite
            document.getElementById('btnRunTestsMain').addEventListener('click', () => AutomatedTestSuite.runAllTests(this));
            document.getElementById('btnRerunTests').addEventListener('click', () => AutomatedTestSuite.runAllTests(this));
            document.getElementById('btnCloseTestModal').addEventListener('click', () => {
                document.getElementById('testRunnerModal').classList.add('hidden');
            });
            document.getElementById('btnCloseTestBottom').addEventListener('click', () => {
                document.getElementById('testRunnerModal').classList.add('hidden');
            });
        }

        openSettingsModal() {
            const m = document.getElementById('settingsModal');
            m.classList.remove('hidden');
            m.classList.add('flex');
        }

        closeSettingsModal() {
            this.save.data.settings.sfxVolume = Number(document.getElementById('sliderSfxVol').value);
            this.save.data.settings.musicVolume = Number(document.getElementById('sliderMusicVol').value);
            this.save.data.settings.touchControls = document.getElementById('toggleTouchControls').checked;
            this.save.data.settings.hazardIndicators = document.getElementById('toggleHazardIndicators').checked;
            this.save.save();
            this.updateTouchVisibility();
            document.getElementById('settingsModal').classList.add('hidden');
            this.ui.showToast('Баптаулар сақталды!');
        }

        openInfoModal(mode) {
            const modal = document.getElementById('infoModal');
            const title = document.getElementById('infoModalTitle');
            const body = document.getElementById('infoModalBody');

            if (mode === 'controls') {
                title.textContent = '🎮 БАСҚАРУ НҰСҚАУЛЫҒЫ (PC & MOBILE)';
                body.innerHTML = `
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono-num text-xs">
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">W, A, S, D</b> — Қозғалу (8 бағытта)</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">Тінтуір (Mouse)</b> — Көздеу (360°)</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">Сол жақ батырма (LMB)</b> — Үздіксіз ату</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">SHIFT</b> — Жылдам жүгіру (Stamina)</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">R</b> — Қаруды қайта оқтау</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">1, 2, 3, 4</b> — Қару түрлерін ауыстыру</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">E</b> — Арсенал дүкенін ашу</div>
                        <div class="bg-slate-900 p-3 rounded border border-slate-800"><b class="text-cyan-400">ESC</b> — Пауза мәзірі</div>
                    </div>
                    <div class="bg-slate-900/70 p-3.5 rounded-lg border border-purple-500/30 text-xs">
                        <b class="text-purple-300">📱 Мобильді құрылғылар:</b> Сол жақ виртуалды джойстик — қозғалу, Оң жақ джойстик — көздеу және автоматты ату, сондай-ақ DASH және ОҚТАУ сенсорлық батырмалары.
                    </div>
                `;
            } else {
                title.textContent = '🏆 CREDITS — ЖОБА ТУРАЛЫ АҚПАРАТ';
                body.innerHTML = `
                    <p><b>CRYSTAL DEFENSE: ZOMBIE APOCALYPSE</b> — HTML5 Canvas, ES6+ JavaScript және Web Audio API негізінде жасалған толыққанды 2D Top-Down Shooter + Base Defense ойыны.</p>
                    <ul class="list-disc pl-5 space-y-1 text-xs text-slate-300">
                        <li><b>Архитектура:</b> 26 модульдік файлдан тұратын таза құрылым (ZIP архив генераторы арқылы толық жүктеледі).</li>
                        <li><b>Жасанды Интеллект (AI):</b> Кедергілерді айналып өту (steering + raycast feelers) және жаулардың бір нүктеге жиналып қалмауы (separation forces).</li>
                        <li><b>Аудио Синтезатор:</b> Сыртқы аудио файлдарға тәуелсіз, барлық 13 дыбыстық эффектіні нақты уақытта генерациялайтын Web Audio API қозғалтқышы.</li>
                    </ul>
                `;
            }

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        loop(timestamp) {
            const rawDt = (timestamp - this.lastFrameTime) / 1000;
            this.lastFrameTime = timestamp;
            const dt = Math.min(0.05, Math.max(0.001, rawDt));

            if (this.state === 'PLAYING') {
                this.updatePlaying(dt);
            } else if (this.state === 'MENU') {
                this.updateMenuBackground(dt);
            }

            this.render();
            requestAnimationFrame((ts) => this.loop(ts));
        }

        updateMenuBackground(dt) {
            this.crystal.update(dt);
            this.camera.update(dt, CONFIG.CRYSTAL_X, CONFIG.CRYSTAL_Y);
            for (const e of this.enemies) {
                e.animTime += dt * 4;
                e.angle = Math.atan2(CONFIG.CRYSTAL_Y - e.y, CONFIG.CRYSTAL_X - e.x);
            }
        }

        updatePlaying(dt) {
            this.elapsedTime += dt;
            this.crystal.update(dt);
            this.player.update(dt, this);
            this.waves.update(dt);

            for (let i = this.projectiles.length - 1; i >= 0; i--) {
                const proj = this.projectiles[i];
                proj.update(dt, this);
                if (proj.dead) this.projectiles.splice(i, 1);
            }

            for (let i = this.enemies.length - 1; i >= 0; i--) {
                const enemy = this.enemies[i];
                enemy.update(dt, this);
                if (enemy.dead) this.enemies.splice(i, 1);
            }

            this.particles.update(dt);
            this.camera.update(dt, this.player.x, this.player.y);
            this.ui.updateHud();
            this.ui.drawMinimap();
        }

        render() {
            const ctx = this.ctx;
            ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

            const offset = this.camera.getRenderOffset();
            ctx.save();
            ctx.translate(-offset.x, -offset.y);

            // 1. World floor, roads, cracks, blood decals & spawn portals
            this.world.draw(ctx, this.camera);

            // 2. Central Energy Crystal
            this.crystal.draw(ctx);

            // 3. Obstacles & 3D walls
            this.world.drawObstacles(ctx, this.camera);

            // 4. Enemies & Bosses
            const showHazards = this.save.data.settings.hazardIndicators;
            for (const e of this.enemies) {
                e.draw(ctx, showHazards);
            }

            // 5. Player
            if (this.state !== 'MENU') {
                this.player.draw(ctx);
            }

            // 6. Projectiles & Particles
            for (const proj of this.projectiles) {
                proj.draw(ctx);
            }
            this.particles.draw(ctx);

            ctx.restore();
        }
    }
