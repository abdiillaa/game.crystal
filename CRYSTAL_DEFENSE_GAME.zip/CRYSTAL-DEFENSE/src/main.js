import { CrystalDefenseGame } from './game.js';
window.addEventListener('DOMContentLoaded', () => { window.gameInstance = new CrystalDefenseGame(); });
