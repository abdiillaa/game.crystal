import { PhysicsEngine } from './collision.js';
export const computePathSteering = PhysicsEngine.computeSteeringDirection.bind(PhysicsEngine);
