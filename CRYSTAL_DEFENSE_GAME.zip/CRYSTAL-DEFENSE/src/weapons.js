import { CONFIG } from './config.js';
export const WEAPON_SPECS = CONFIG.WEAPONS;
