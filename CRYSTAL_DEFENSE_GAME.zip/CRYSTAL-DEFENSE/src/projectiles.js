import { CONFIG } from './config.js';
import { PhysicsEngine } from './collision.js';
export class Projectile {
        constructor(opts) {
            this.x = opts.x;
            this.y = opts.y;
            this.vx = opts.vx;
            this.vy = opts.vy;
            this.angle = Math.atan2(opts.vy, opts.vx);
            this.speed = opts.speed;
            this.damage = opts.damage;
            this.color = opts.color || '#00F0FF';
            this.radius = opts.radius || 4;
            this.fromPlayer = opts.fromPlayer;
            this.pierce = opts.pierce || 1;
            this.robotBonus = opts.robotBonus || 1.0;
            this.explosiveRadius = opts.explosiveRadius || 0;
            this.falloff = opts.falloff || false;
            this.maxDist = opts.maxDist || 1000;
            this.traveled = 0;
            this.hitEntities = new Set(); // Ensures 1 bullet damages each enemy only ONCE
            this.dead = false;
        }

        update(dt, game) {
            if (this.dead) return;
            const stepX = this.vx * dt;
            const stepY = this.vy * dt;
            this.x += stepX;
            this.y += stepY;
            this.traveled += Math.hypot(stepX, stepY);

            if (this.traveled >= this.maxDist ||
                this.x < 0 || this.x > CONFIG.WORLD_WIDTH ||
                this.y < 0 || this.y > CONFIG.WORLD_HEIGHT) {
                this.dead = true;
                return;
            }

            // Obstacle collision
            for (const ob of game.world.obstacles) {
                if (PhysicsEngine.circleRectCollide(this.x, this.y, this.radius, ob.x, ob.y, ob.w, ob.h)) {
                    game.particles.spawnBurst(this.x, this.y, this.color, 5, 110);
                    if (this.explosiveRadius > 0 && this.fromPlayer) {
                        this.triggerExplosion(game);
                    }
                    this.dead = true;
                    return;
                }
            }

            if (this.fromPlayer) {
                // Note: Player bullets NEVER damage the Crystal (per spec requirement)
                for (const enemy of game.enemies) {
                    if (enemy.dead || this.hitEntities.has(enemy.uid)) continue;
                    const dist = Math.hypot(this.x - enemy.x, this.y - enemy.y);
                    if (dist <= this.radius + enemy.radius) {
                        this.hitEntities.add(enemy.uid);

                        let finalDmg = this.damage;
                        if (this.falloff) {
                            const falloffMult = Math.max(0.35, 1 - (this.traveled / this.maxDist) * 0.65);
                            finalDmg *= falloffMult;
                        }
                        if (enemy.type === 'robot' || enemy.id === 'mecha') {
                            finalDmg *= this.robotBonus;
                        }

                        enemy.takeDamage(finalDmg, game);
                        game.audio.playHit();
                        game.particles.spawnBurst(this.x, this.y, this.color, 6, 140);

                        if (this.explosiveRadius > 0) {
                            this.triggerExplosion(game);
                        }

                        this.pierce -= 1;
                        if (this.pierce <= 0) {
                            this.dead = true;
                            break;
                        }
                    }
                }
            } else {
                // Enemy projectile (from Assault Robot or Bosses)
                const distPlayer = Math.hypot(this.x - game.player.x, this.y - game.player.y);
                if (distPlayer <= this.radius + game.player.radius) {
                    game.player.takeDamage(this.damage, game);
                    game.particles.spawnBurst(this.x, this.y, '#EF4444', 7, 130);
                    this.dead = true;
                    return;
                }

                const distCrystal = Math.hypot(this.x - game.crystal.x, this.y - game.crystal.y);
                if (distCrystal <= this.radius + game.crystal.radius) {
                    game.crystal.takeDamage(this.damage, game);
                    game.particles.spawnBurst(this.x, this.y, '#EF4444', 7, 130);
                    this.dead = true;
                    return;
                }
            }
        }

        triggerExplosion(game) {
            game.particles.spawnExplosion(this.x, this.y, '#A855F7', this.explosiveRadius);
            const hitOnce = new Set();
            for (const enemy of game.enemies) {
                if (enemy.dead || hitOnce.has(enemy.uid)) continue;
                const d = Math.hypot(enemy.x - this.x, enemy.y - this.y);
                if (d <= this.explosiveRadius + enemy.radius) {
                    hitOnce.add(enemy.uid);
                    enemy.takeDamage(this.damage * 0.55, game);
                }
            }
        }

        draw(ctx) {
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            ctx.shadowColor = this.color;
            ctx.shadowBlur = 10;
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.roundRect(-10, -this.radius * 0.7, 18, this.radius * 1.4, 3);
            ctx.fill();

            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(-4, -this.radius * 0.35, 10, this.radius * 0.7);
            ctx.restore();
        }
    }
