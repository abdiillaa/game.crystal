import { PhysicsEngine } from './collision.js';
export const EnemyAI = { computeSteering: PhysicsEngine.computeSteeringDirection };
