export class InputController {
        constructor(canvas, game) {
            this.canvas = canvas;
            this.game = game;
            this.keys = {};
            this.mouse = { x: window.innerWidth / 2, y: window.innerHeight / 2, worldX: 1200, worldY: 1200, down: false };
            this.isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;

            // Virtual Joysticks state
            this.joyMove = { active: false, id: null, startX: 0, startY: 0, dx: 0, dy: 0 };
            this.joyAim = { active: false, id: null, startX: 0, startY: 0, dx: 0, dy: 0 };

            this.bindEvents();
        }

        bindEvents() {
            window.addEventListener('keydown', (e) => {
                const code = e.code;
                this.keys[code] = true;

                if (this.game.state === 'PLAYING') {
                    if (code === 'Digit1') this.game.player.switchWeapon(0);
                    if (code === 'Digit2') this.game.player.switchWeapon(1);
                    if (code === 'Digit3') this.game.player.switchWeapon(2);
                    if (code === 'Digit4') this.game.player.switchWeapon(3);
                    if (code === 'KeyR') this.game.player.startReload();
                    if (code === 'KeyE') this.game.toggleShopModal();
                    if (code === 'Escape') this.game.togglePause();
                } else if (this.game.state === 'SHOP') {
                    if (code === 'Escape' || code === 'KeyE') this.game.toggleShopModal(false);
                } else if (this.game.state === 'PAUSED') {
                    if (code === 'Escape') this.game.togglePause();
                }
            });

            window.addEventListener('keyup', (e) => {
                this.keys[e.code] = false;
            });

            this.canvas.addEventListener('mousemove', (e) => {
                const rect = this.canvas.getBoundingClientRect();
                this.mouse.x = e.clientX - rect.left;
                this.mouse.y = e.clientY - rect.top;
            });

            this.canvas.addEventListener('mousedown', (e) => {
                if (e.button === 0) {
                    this.game.audio.resume();
                    this.mouse.down = true;
                }
            });

            window.addEventListener('mouseup', (e) => {
                if (e.button === 0) {
                    this.mouse.down = false;
                }
            });

            // Mobile Joysticks Binding
            const moveZone = document.getElementById('joyMoveZone');
            const moveStick = document.getElementById('joyMoveStick');
            const aimZone = document.getElementById('joyAimZone');
            const aimStick = document.getElementById('joyAimStick');

            const handleZoneTouch = (zone, stick, stateObj, isAim) => {
                zone.addEventListener('touchstart', (e) => {
                    e.preventDefault();
                    this.game.audio.resume();
                    const touch = e.changedTouches[0];
                    const rect = zone.getBoundingClientRect();
                    stateObj.active = true;
                    stateObj.id = touch.identifier;
                    stateObj.startX = rect.left + rect.width / 2;
                    stateObj.startY = rect.top + rect.height / 2;
                    this.updateStick(touch.clientX, touch.clientY, stick, stateObj, 42);
                }, { passive: false });

                zone.addEventListener('touchmove', (e) => {
                    e.preventDefault();
                    for (let i = 0; i < e.changedTouches.length; i++) {
                        const t = e.changedTouches[i];
                        if (t.identifier === stateObj.id) {
                            this.updateStick(t.clientX, t.clientY, stick, stateObj, 42);
                        }
                    }
                }, { passive: false });

                const endTouch = (e) => {
                    for (let i = 0; i < e.changedTouches.length; i++) {
                        const t = e.changedTouches[i];
                        if (t.identifier === stateObj.id) {
                            stateObj.active = false;
                            stateObj.id = null;
                            stateObj.dx = 0;
                            stateObj.dy = 0;
                            stick.style.transform = `translate(0px, 0px)`;
                        }
                    }
                };
                zone.addEventListener('touchend', endTouch);
                zone.addEventListener('touchcancel', endTouch);
            };

            handleZoneTouch(moveZone, moveStick, this.joyMove, false);
            handleZoneTouch(aimZone, aimStick, this.joyAim, true);

            // Mobile Buttons
            const btnDash = document.getElementById('btnMobileDash');
            const btnReload = document.getElementById('btnMobileReload');
            btnDash.addEventListener('touchstart', (e) => { e.preventDefault(); this.keys['ShiftLeft'] = true; });
            btnDash.addEventListener('touchend', (e) => { e.preventDefault(); this.keys['ShiftLeft'] = false; });
            btnReload.addEventListener('touchstart', (e) => { e.preventDefault(); this.game.player.startReload(); });
        }

        updateStick(clientX, clientY, stickEl, stateObj, maxRadius) {
            let vx = clientX - stateObj.startX;
            let vy = clientY - stateObj.startY;
            const dist = Math.hypot(vx, vy);
            if (dist > maxRadius) {
                vx = (vx / dist) * maxRadius;
                vy = (vy / dist) * maxRadius;
            }
            stickEl.style.transform = `translate(${vx}px, ${vy}px)`;
            stateObj.dx = vx / maxRadius;
            stateObj.dy = vy / maxRadius;
        }

        getMoveVector() {
            let mx = 0;
            let my = 0;
            if (this.keys['KeyW'] || this.keys['ArrowUp']) my -= 1;
            if (this.keys['KeyS'] || this.keys['ArrowDown']) my += 1;
            if (this.keys['KeyA'] || this.keys['ArrowLeft']) mx -= 1;
            if (this.keys['KeyD'] || this.keys['ArrowRight']) mx += 1;

            if (this.joyMove.active) {
                mx += this.joyMove.dx;
                my += this.joyMove.dy;
            }

            // Normalize diagonal speed so diagonal movement is never faster than cardinal movement
            const len = Math.hypot(mx, my);
            if (len > 1) {
                mx /= len;
                my /= len;
            }
            return { x: mx, y: my };
        }

        isSprinting() {
            return !!(this.keys['ShiftLeft'] || this.keys['ShiftRight']);
        }

        isFiring() {
            return this.mouse.down || (this.joyAim.active && Math.hypot(this.joyAim.dx, this.joyAim.dy) > 0.25);
        }
    }
