import { CONFIG } from './config.js';
import { Enemy } from './enemies.js';
import { BossEnemy } from './boss.js';
export class WaveManager {
        constructor(game) {
            this.game = game;
            this.currentWave = 1;
            this.maxCampaignWave = 10;
            this.spawnQueue = [];
            this.spawnTimer = 0;
            this.spawnInterval = 0.85;
            this.inIntermission = false;
            this.intermissionTimer = 0;
            this.activeBoss = null;
        }

        /**
         * Exact Wave Compositions matching section 13 & 14 of the prompt:
         * Wave 1: 10 zombies
         * Wave 2: 10 zombies, 3 robots
         * Wave 3: 12 zombies, 4 fast zombies, 3 robots
         * Wave 4: 10 zombies, 5 fast zombies, 3 heavy zombies, 4 robots
         * Wave 5: First Boss (MUTANT TITAN) + support
         * Waves 6-9: Escalating combined arms with explosive mutants
         * Wave 10: Final Boss (MECHA DESTROYER)
         * Wave 11 (Bonus Mode): SHADOW OVERLORD
         */
        buildWaveQueue(waveNum) {
            const q = [];
            const pushMany = (type, count) => {
                for (let i = 0; i < count; i++) q.push(type);
            };

            if (waveNum === 1) {
                pushMany('normal', 10);
            } else if (waveNum === 2) {
                pushMany('normal', 10);
                pushMany('robot', 3);
            } else if (waveNum === 3) {
                pushMany('normal', 12);
                pushMany('fast', 4);
                pushMany('robot', 3);
            } else if (waveNum === 4) {
                pushMany('normal', 10);
                pushMany('fast', 5);
                pushMany('heavy', 3);
                pushMany('robot', 4);
            } else if (waveNum === 5) {
                q.push('BOSS_TITAN');
                pushMany('normal', 6);
                pushMany('fast', 4);
            } else if (waveNum === 6) {
                pushMany('normal', 12);
                pushMany('fast', 6);
                pushMany('explosive', 4);
                pushMany('robot', 5);
            } else if (waveNum === 7) {
                pushMany('normal', 14);
                pushMany('heavy', 5);
                pushMany('explosive', 5);
                pushMany('robot', 6);
            } else if (waveNum === 8) {
                pushMany('fast', 10);
                pushMany('heavy', 6);
                pushMany('explosive', 6);
                pushMany('robot', 7);
            } else if (waveNum === 9) {
                pushMany('normal', 15);
                pushMany('fast', 10);
                pushMany('heavy', 7);
                pushMany('explosive', 6);
                pushMany('robot', 8);
            } else if (waveNum === 10) {
                q.push('BOSS_MECHA');
                pushMany('robot', 4);
                pushMany('heavy', 3);
            } else {
                q.push('BOSS_OVERLORD');
                pushMany('fast', 8);
                pushMany('robot', 6);
                pushMany('explosive', 5);
            }

            return q;
        }

        startWave(waveNum) {
            this.currentWave = waveNum;
            this.inIntermission = false;
            this.spawnQueue = this.buildWaveQueue(waveNum);
            this.spawnTimer = 0.4;
            this.spawnInterval = Math.max(0.42, 0.92 - waveNum * 0.04);
            this.activeBoss = null;

            const isBossWave = (waveNum === 5 || waveNum === 10 || waveNum >= 11);
            if (isBossWave) {
                this.game.audio.playBossSpawn();
                this.game.ui.announceWave(
                    `⚠ БАСТЫҚ ТОЛҚЫНЫ ${waveNum}`,
                    waveNum === 5 ? 'MUTANT TITAN ЖАҚЫНДАП КЕЛЕДІ!' :
                    waveNum === 10 ? 'MECHA DESTROYER ШАБУЫЛҒА ШЫҚТЫ!' : 'SHADOW OVERLORD ПАЙДА БОЛДЫ!'
                );
            } else {
                this.game.audio.playWaveStart();
                this.game.ui.announceWave(`ТОЛҚЫН ${waveNum} БАСТАЛДЫ`, 'КРИСТАЛДЫ ҚОРҒАҢЫЗ');
            }

            // Auto-save campaign progress at the start of every wave
            this.game.saveSnapshot();
        }

        update(dt) {
            if (this.inIntermission) {
                this.intermissionTimer -= dt;
                if (this.intermissionTimer <= 0) {
                    this.startWave(this.currentWave + 1);
                }
                return;
            }

            // Spawn enemies from perimeter portals
            if (this.spawnQueue.length > 0) {
                this.spawnTimer -= dt;
                if (this.spawnTimer <= 0) {
                    this.spawnTimer = this.spawnInterval;
                    const nextType = this.spawnQueue.shift();
                    const portals = this.game.world.spawnPortals;
                    const portal = portals[Math.floor(Math.random() * portals.length)];
                    const scale = 1 + (this.currentWave - 1) * 0.08;

                    if (nextType === 'BOSS_TITAN') {
                        const boss = new BossEnemy('titan', portal.x, portal.y);
                        this.activeBoss = boss;
                        this.game.enemies.push(boss);
                    } else if (nextType === 'BOSS_MECHA') {
                        const boss = new BossEnemy('mecha', portal.x, portal.y);
                        this.activeBoss = boss;
                        this.game.enemies.push(boss);
                    } else if (nextType === 'BOSS_OVERLORD') {
                        const boss = new BossEnemy('overlord', portal.x, portal.y);
                        this.activeBoss = boss;
                        this.game.enemies.push(boss);
                    } else {
                        this.game.enemies.push(new Enemy(nextType, portal.x, portal.y, scale));
                    }
                }
            }

            // Check if wave is cleared
            const aliveCount = this.game.enemies.length;
            if (this.spawnQueue.length === 0 && aliveCount === 0) {
                this.onWaveCleared();
            }
        }

        onWaveCleared() {
            this.activeBoss = null;
            if (this.currentWave === 10) {
                // Main campaign Victory condition!
                this.game.triggerGameOver(true, '10-толқынның соңғы бастығы MECHA DESTROYER талқандалды!');
                return;
            }
            if (this.currentWave >= 11) {
                this.game.triggerGameOver(true, 'SHADOW OVERLORD жеңілді! Сіз нағыз аңызсыз!');
                return;
            }

            this.inIntermission = true;
            this.intermissionTimer = CONFIG.INTERMISSION_SECONDS;
            this.game.player.money += 60 + this.currentWave * 15;
            this.game.ui.showToast(`Толқын ${this.currentWave} тазартылды! Дүкен ашық (E).`);
            this.game.saveSnapshot();
        }
    }
