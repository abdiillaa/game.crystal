import { CONFIG } from './config.js';
export class UIManager {
        constructor(game) {
            this.game = game;
            this.minimapCanvas = document.getElementById('minimapCanvas');
            this.minimapCtx = this.minimapCanvas.getContext('2d');
        }

        updateHud() {
            const g = this.game;
            const p = g.player;
            const c = g.crystal;
            const w = p.currentWeapon;

            const remainingEnemies = g.enemies.length + g.waves.spawnQueue.length;
            document.getElementById('hudWaveNum').textContent = `${g.waves.currentWave} / 10`;
            document.getElementById('hudEnemiesLeft').textContent = remainingEnemies;
            document.getElementById('hudMoney').textContent = `$${p.money}`;
            document.getElementById('hudKills').textContent = p.kills;

            const mins = String(Math.floor(g.elapsedTime / 60)).padStart(2, '0');
            const secs = String(Math.floor(g.elapsedTime % 60)).padStart(2, '0');
            document.getElementById('hudTimer').textContent = `${mins}:${secs}`;

            // Crystal HP Bar
            document.getElementById('hudCrystalHpText').textContent = `${Math.ceil(c.hp)} / ${c.maxHp} HP`;
            document.getElementById('hudCrystalHpBar').style.width = `${(c.hp / c.maxHp) * 100}%`;

            // Boss Bar
            const bossPanel = document.getElementById('hudBossPanel');
            if (g.waves.activeBoss && !g.waves.activeBoss.dead) {
                const b = g.waves.activeBoss;
                bossPanel.classList.remove('hidden');
                document.getElementById('hudBossName').textContent = `⚠ ${b.name}`;
                document.getElementById('hudBossHpText').textContent = `${Math.ceil(b.hp)} / ${b.maxHp}`;
                document.getElementById('hudBossHpBar').style.width = `${(b.hp / b.maxHp) * 100}%`;
            } else {
                bossPanel.classList.add('hidden');
            }

            // Intermission Banner
            const interBox = document.getElementById('hudIntermissionBox');
            if (g.waves.inIntermission) {
                interBox.classList.remove('hidden');
                document.getElementById('hudIntermissionTimer').textContent = Math.ceil(g.waves.intermissionTimer);
            } else {
                interBox.classList.add('hidden');
            }

            // Player Bars
            document.getElementById('hudPlayerHpText').textContent = `${Math.ceil(p.hp)} / ${p.maxHp}`;
            document.getElementById('hudPlayerHpBar').style.width = `${(p.hp / p.maxHp) * 100}%`;

            document.getElementById('hudPlayerShieldText').textContent = `${Math.ceil(p.shield)} / ${p.maxShield}`;
            document.getElementById('hudPlayerShieldBar').style.width = `${(p.shield / p.maxShield) * 100}%`;

            document.getElementById('hudStaminaText').textContent = `${Math.round(p.stamina)}%`;
            document.getElementById('hudStaminaBar').style.width = `${(p.stamina / p.maxStamina) * 100}%`;

            // Weapon & Reload Telemetry
            document.getElementById('hudWeaponName').textContent = w.name;
            document.getElementById('hudAmmoClip').textContent = w.clip;
            document.getElementById('hudAmmoReserve').textContent = w.infiniteReserve ? '∞' : w.reserve;

            const reloadWrap = document.getElementById('hudReloadBarWrap');
            const reloadStatus = document.getElementById('hudReloadStatus');
            if (p.reloading) {
                reloadWrap.classList.remove('hidden');
                const prog = (1 - p.reloadTimer / p.reloadDuration) * 100;
                document.getElementById('hudReloadBar').style.width = `${prog}%`;
                reloadStatus.textContent = 'ҚАЙТА ОҚТАЛУДА...';
                reloadStatus.className = 'text-xs text-amber-400 font-bold';
            } else {
                reloadWrap.classList.add('hidden');
                reloadStatus.textContent = 'АТУҒА ДАЙЫН (R - ОҚТАУ)';
                reloadStatus.className = 'text-xs text-slate-400 font-semibold';
            }

            // Highlight active weapon tab
            document.querySelectorAll('.weapon-slot-btn').forEach((btn, idx) => {
                if (idx === p.currentWeaponIndex) {
                    btn.className = 'weapon-slot-btn hud-panel px-2.5 py-1.5 rounded text-xs font-display font-bold border-cyan-400 text-cyan-300 flex items-center gap-1.5';
                } else {
                    btn.className = 'weapon-slot-btn hud-panel px-2.5 py-1.5 rounded text-xs font-display font-bold text-slate-400 flex items-center gap-1.5';
                }
            });
        }

        drawMinimap() {
            const ctx = this.minimapCtx;
            const mw = this.minimapCanvas.width;
            const mh = this.minimapCanvas.height;
            const scaleX = mw / CONFIG.WORLD_WIDTH;
            const scaleY = mh / CONFIG.WORLD_HEIGHT;

            ctx.fillStyle = '#06090E';
            ctx.fillRect(0, 0, mw, mh);

            // Obstacles
            ctx.fillStyle = '#334155';
            for (const ob of this.game.world.obstacles) {
                ctx.fillRect(ob.x * scaleX, ob.y * scaleY, ob.w * scaleX, ob.h * scaleY);
            }

            // Crystal
            ctx.fillStyle = '#00F0FF';
            ctx.beginPath();
            ctx.arc(this.game.crystal.x * scaleX, this.game.crystal.y * scaleY, 4.5, 0, Math.PI * 2);
            ctx.fill();

            // Enemies
            for (const e of this.game.enemies) {
                if (e.dead) continue;
                ctx.fillStyle = e.isBoss ? '#A855F7' : '#EF4444';
                ctx.beginPath();
                ctx.arc(e.x * scaleX, e.y * scaleY, e.isBoss ? 4 : 2.2, 0, Math.PI * 2);
                ctx.fill();
            }

            // Player
            ctx.fillStyle = '#22C55E';
            ctx.beginPath();
            ctx.arc(this.game.player.x * scaleX, this.game.player.y * scaleY, 3.5, 0, Math.PI * 2);
            ctx.fill();
        }

        announceWave(mainText, subText) {
            const box = document.getElementById('waveAnnouncement');
            document.getElementById('waveAnnounceMain').textContent = mainText;
            document.getElementById('waveAnnounceSub').textContent = subText;
            box.classList.remove('opacity-0', 'scale-90');
            box.classList.add('opacity-100', 'scale-100');
            setTimeout(() => {
                box.classList.remove('opacity-100', 'scale-100');
                box.classList.add('opacity-0', 'scale-90');
            }, 2600);
        }

        showToast(msg) {
            const t = document.getElementById('toastBanner');
            t.textContent = msg;
            t.style.opacity = '1';
            clearTimeout(this.toastTimeout);
            this.toastTimeout = setTimeout(() => { t.style.opacity = '0'; }, 2400);
        }

        refreshMainMenuStats() {
            const d = this.game.save.data;
            document.getElementById('menuStatBestWave').textContent = d.bestWave;
            document.getElementById('menuStatHighScore').textContent = d.highScore;
            document.getElementById('menuStatTotalKills').textContent = d.totalKills;
            document.getElementById('menuStatVictories').textContent = d.victories;
            document.getElementById('btnContinueGame').disabled = !d.activeRun;
        }
    }
