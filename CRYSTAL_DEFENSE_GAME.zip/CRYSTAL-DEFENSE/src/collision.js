import { CONFIG } from './config.js';
export class PhysicsEngine {
        static circleRectCollide(cx, cy, cr, rx, ry, rw, rh) {
            const closestX = Math.max(rx, Math.min(cx, rx + rw));
            const closestY = Math.max(ry, Math.min(cy, ry + rh));
            const dx = cx - closestX;
            const dy = cy - closestY;
            return (dx * dx + dy * dy) < (cr * cr);
        }

        static resolveCircleObstacle(entity, obstacles) {
            // Keep inside world boundaries
            entity.x = Math.max(entity.radius + 8, Math.min(CONFIG.WORLD_WIDTH - entity.radius - 8, entity.x));
            entity.y = Math.max(entity.radius + 8, Math.min(CONFIG.WORLD_HEIGHT - entity.radius - 8, entity.y));

            for (const ob of obstacles) {
                const closestX = Math.max(ob.x, Math.min(entity.x, ob.x + ob.w));
                const closestY = Math.max(ob.y, Math.min(entity.y, ob.y + ob.h));
                const dx = entity.x - closestX;
                const dy = entity.y - closestY;
                const distSq = dx * dx + dy * dy;

                if (distSq < entity.radius * entity.radius) {
                    const dist = Math.sqrt(distSq) || 0.001;
                    const overlap = entity.radius - dist;
                    entity.x += (dx / dist) * overlap;
                    entity.y += (dy / dist) * overlap;
                }
            }
        }

        /**
         * Obstacle-avoiding steering + ray-feeler pathfinding so enemies smoothly
         * navigate around walls without getting stuck.
         */
        static computeSteeringDirection(enemy, targetX, targetY, obstacles, allEnemies) {
            let desiredAngle = Math.atan2(targetY - enemy.y, targetX - enemy.x);
            const lookAhead = enemy.radius + 48;

            // Check if direct line to target intersects an obstacle
            const testX = enemy.x + Math.cos(desiredAngle) * lookAhead;
            const testY = enemy.y + Math.sin(desiredAngle) * lookAhead;

            let blocked = false;
            for (const ob of obstacles) {
                if (this.circleRectCollide(testX, testY, enemy.radius + 6, ob.x, ob.y, ob.w, ob.h)) {
                    blocked = true;
                    break;
                }
            }

            if (blocked) {
                // Sample alternative angles left & right to steer around the wall
                const offsets = [0.45, -0.45, 0.9, -0.9, 1.35, -1.35, 1.8, -1.8];
                for (const off of offsets) {
                    const candAngle = desiredAngle + off;
                    const cx = enemy.x + Math.cos(candAngle) * lookAhead;
                    const cy = enemy.y + Math.sin(candAngle) * lookAhead;
                    let clear = true;
                    for (const ob of obstacles) {
                        if (this.circleRectCollide(cx, cy, enemy.radius + 4, ob.x, ob.y, ob.w, ob.h)) {
                            clear = false;
                            break;
                        }
                    }
                    if (clear) {
                        desiredAngle = candAngle;
                        break;
                    }
                }
            }

            let vx = Math.cos(desiredAngle);
            let vy = Math.sin(desiredAngle);

            // Separation force so enemies don't stack on a single point
            let sepX = 0, sepY = 0;
            for (const other of allEnemies) {
                if (other === enemy || other.dead) continue;
                const dx = enemy.x - other.x;
                const dy = enemy.y - other.y;
                const minDist = enemy.radius + other.radius + 6;
                const dSq = dx * dx + dy * dy;
                if (dSq > 0 && dSq < minDist * minDist) {
                    const d = Math.sqrt(dSq);
                    const push = (minDist - d) / minDist;
                    sepX += (dx / d) * push * 1.35;
                    sepY += (dy / d) * push * 1.35;
                }
            }

            vx += sepX;
            vy += sepY;
            const len = Math.hypot(vx, vy) || 1;
            return { x: vx / len, y: vy / len, angle: Math.atan2(vy, vx) };
        }
    }
