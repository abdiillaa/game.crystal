import { CONFIG } from './config.js';
import { Enemy } from './enemies.js';
import { PhysicsEngine } from './collision.js';
import { Projectile } from './projectiles.js';
export class BossEnemy extends Enemy {
        constructor(bossKey, x, y) {
            super('heavy', x, y, 1);
            const cfg = CONFIG.BOSSES[bossKey];
            this.isBoss = true;
            this.bossKey = bossKey;
            this.id = cfg.id;
            this.name = cfg.name;
            this.maxHp = cfg.hp;
            this.hp = cfg.hp;
            this.speed = cfg.speed;
            this.radius = cfg.radius;
            this.damage = cfg.damage;
            this.reward = cfg.reward;
            this.score = cfg.score;
            this.color = cfg.color;
            this.armor = 1.0;

            this.skillTimer = 3.5;
            this.summonTimer = 9.0;
            this.shieldActive = false;
            this.shieldTimer = 0;
            this.hazardZones = [];
        }

        takeDamage(amount, game) {
            if (this.shieldActive) {
                amount *= 0.2; // 80% damage reduction while Mecha shield is active
            }
            super.takeDamage(amount, game);
        }

        update(dt, game) {
            if (this.dead) return;
            this.animTime += dt * 5;
            if (this.hitFlash > 0) this.hitFlash -= dt;
            if (this.attackCooldown > 0) this.attackCooldown -= dt;

            // Enrage at < 45% HP
            const enraged = (this.hp / this.maxHp) < 0.45;
            const speedMult = enraged ? 1.32 : 1.0;

            if (this.shieldActive) {
                this.shieldTimer -= dt;
                if (this.shieldTimer <= 0) this.shieldActive = false;
            }

            // Update telegraphed ground hazard zones
            for (let i = this.hazardZones.length - 1; i >= 0; i--) {
                const hz = this.hazardZones[i];
                hz.timer -= dt;
                if (hz.timer <= 0) {
                    game.audio.playExplosion();
                    game.camera.shake(9, 0.25);
                    game.particles.spawnExplosion(hz.x, hz.y, hz.color, hz.radius);
                    if (Math.hypot(game.player.x - hz.x, game.player.y - hz.y) <= hz.radius + game.player.radius) {
                        game.player.takeDamage(this.damage * 1.1, game);
                    }
                    if (Math.hypot(game.crystal.x - hz.x, game.crystal.y - hz.y) <= hz.radius + game.crystal.radius) {
                        game.crystal.takeDamage(this.damage * 0.85, game);
                    }
                    this.hazardZones.splice(i, 1);
                }
            }

            // Boss movement towards Player or Crystal
            const distPlayer = Math.hypot(game.player.x - this.x, game.player.y - this.y);
            const distCrystal = Math.hypot(game.crystal.x - this.x, game.crystal.y - this.y);
            const target = distPlayer < 520 ? game.player : game.crystal;
            const targetDist = Math.hypot(target.x - this.x, target.y - this.y);

            if (targetDist > this.radius + target.radius + 10) {
                const steer = PhysicsEngine.computeSteeringDirection(this, target.x, target.y, game.world.obstacles, game.enemies);
                this.x += steer.x * this.speed * speedMult * dt;
                this.y += steer.y * this.speed * speedMult * dt;
                this.angle = steer.angle;
            } else if (this.attackCooldown <= 0) {
                this.attackCooldown = 1.1;
                target.takeDamage(this.damage, game);
                game.camera.shake(8, 0.2);
            }

            PhysicsEngine.resolveCircleObstacle(this, game.world.obstacles);

            // Special Boss Attacks
            this.skillTimer -= dt * speedMult;
            if (this.skillTimer <= 0) {
                this.skillTimer = 4.2;
                this.executeSpecialSkill(game);
            }

            // Minion Summoning
            this.summonTimer -= dt;
            if (this.summonTimer <= 0) {
                this.summonTimer = 11.5;
                this.summonMinions(game);
            }
        }

        executeSpecialSkill(game) {
            if (this.bossKey === 'titan') {
                // 360-degree radial toxic spine barrage
                const count = 14;
                for (let i = 0; i < count; i++) {
                    const a = (Math.PI * 2 * i) / count + this.animTime;
                    game.projectiles.push(new Projectile({
                        x: this.x,
                        y: this.y,
                        vx: Math.cos(a) * 430,
                        vy: Math.sin(a) * 430,
                        speed: 430,
                        damage: 18,
                        color: '#84CC16',
                        radius: 6,
                        fromPlayer: false,
                        maxDist: 700
                    }));
                }
                game.audio.playExplosion();
            } else if (this.bossKey === 'mecha') {
                // Activate temporary shield + spawn orbital strike hazard zones on Player & Crystal
                this.shieldActive = true;
                this.shieldTimer = 2.8;
                for (let i = 0; i < 3; i++) {
                    const tx = game.player.x + (Math.random() - 0.5) * 220;
                    const ty = game.player.y + (Math.random() - 0.5) * 220;
                    this.hazardZones.push({ x: tx, y: ty, radius: 95, timer: 1.45, maxTimer: 1.45, color: '#EF4444' });
                }
                // Targeted laser burst
                const aim = Math.atan2(game.player.y - this.y, game.player.x - this.x);
                for (let s = -2; s <= 2; s++) {
                    const a = aim + s * 0.14;
                    game.projectiles.push(new Projectile({
                        x: this.x,
                        y: this.y,
                        vx: Math.cos(a) * 620,
                        vy: Math.sin(a) * 620,
                        speed: 620,
                        damage: 22,
                        color: '#EF4444',
                        radius: 6,
                        fromPlayer: false,
                        maxDist: 900
                    }));
                }
                game.audio.playRobotLaser();
            } else if (this.bossKey === 'overlord') {
                // Shadow Overlord Void Vortex + radial plasma burst
                for (let i = 0; i < 4; i++) {
                    this.hazardZones.push({
                        x: game.player.x + (Math.random() - 0.5) * 260,
                        y: game.player.y + (Math.random() - 0.5) * 260,
                        radius: 105,
                        timer: 1.25,
                        maxTimer: 1.25,
                        color: '#A855F7'
                    });
                }
                const count = 18;
                for (let i = 0; i < count; i++) {
                    const a = (Math.PI * 2 * i) / count;
                    game.projectiles.push(new Projectile({
                        x: this.x,
                        y: this.y,
                        vx: Math.cos(a) * 540,
                        vy: Math.sin(a) * 540,
                        speed: 540,
                        damage: 24,
                        color: '#A855F7',
                        radius: 6,
                        fromPlayer: false,
                        maxDist: 850
                    }));
                }
            }
        }

        summonMinions(game) {
            if (game.enemies.length > 35) return;
            const subType = this.bossKey === 'mecha' ? 'robot' : 'fast';
            for (let i = 0; i < 2; i++) {
                const a = Math.random() * Math.PI * 2;
                const sx = this.x + Math.cos(a) * 80;
                const sy = this.y + Math.sin(a) * 80;
                game.enemies.push(new Enemy(subType, sx, sy, 1.1));
            }
        }

        draw(ctx, showHazards = true) {
            // Draw telegraphed hazard zones on ground
            if (showHazards) {
                for (const hz of this.hazardZones) {
                    const p = 1 - hz.timer / hz.maxTimer;
                    ctx.save();
                    ctx.fillStyle = `rgba(239, 68, 68, ${0.15 + p * 0.3})`;
                    ctx.strokeStyle = hz.color;
                    ctx.lineWidth = 2.5;
                    ctx.beginPath();
                    ctx.arc(hz.x, hz.y, hz.radius, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.stroke();

                    ctx.beginPath();
                    ctx.arc(hz.x, hz.y, hz.radius * p, 0, Math.PI * 2);
                    ctx.stroke();
                    ctx.restore();
                }
            }

            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            // Boss Aura
            ctx.strokeStyle = this.color;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(0, 0, this.radius + 10, 0, Math.PI * 2);
            ctx.stroke();

            if (this.shieldActive) {
                ctx.fillStyle = 'rgba(0, 240, 255, 0.25)';
                ctx.strokeStyle = '#00F0FF';
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.arc(0, 0, this.radius + 18, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
            }

            // Boss Chassis / Bio-Body
            ctx.fillStyle = this.hitFlash > 0 ? '#FFFFFF' : '#111827';
            ctx.strokeStyle = this.color;
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            // Shoulder Cannons / Mutant Claws
            ctx.fillStyle = this.color;
            ctx.fillRect(10, -this.radius - 6, 34, 14);
            ctx.fillRect(10, this.radius - 8, 34, 14);

            // Glowing Core
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath();
            ctx.arc(8, 0, 14, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }
    }
