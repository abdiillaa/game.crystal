import { CONFIG } from './config.js';
export class Camera {
        constructor(width, height) {
            this.x = CONFIG.CRYSTAL_X - width / 2;
            this.y = CONFIG.CRYSTAL_Y - height / 2;
            this.width = width;
            this.height = height;
            this.shakeTimer = 0;
            this.shakeIntensity = 0;
        }

        resize(w, h) {
            this.width = w;
            this.height = h;
        }

        shake(intensity = 6, duration = 0.2) {
            this.shakeIntensity = Math.max(this.shakeIntensity, intensity);
            this.shakeTimer = Math.max(this.shakeTimer, duration);
        }

        update(dt, targetX, targetY) {
            const desiredX = targetX - this.width / 2;
            const desiredY = targetY - this.height / 2;

            // Smooth camera follow with lerp
            const smooth = 1 - Math.exp(-8 * dt);
            this.x += (desiredX - this.x) * smooth;
            this.y += (desiredY - this.y) * smooth;

            // Clamp to World Boundaries
            const maxX = Math.max(0, CONFIG.WORLD_WIDTH - this.width);
            const maxY = Math.max(0, CONFIG.WORLD_HEIGHT - this.height);
            this.x = Math.max(0, Math.min(maxX, this.x));
            this.y = Math.max(0, Math.min(maxY, this.y));

            if (this.shakeTimer > 0) {
                this.shakeTimer -= dt;
                if (this.shakeTimer <= 0) this.shakeIntensity = 0;
            }
        }

        getRenderOffset() {
            if (this.shakeTimer > 0) {
                return {
                    x: this.x + (Math.random() * 2 - 1) * this.shakeIntensity,
                    y: this.y + (Math.random() * 2 - 1) * this.shakeIntensity
                };
            }
            return { x: this.x, y: this.y };
        }
    }
