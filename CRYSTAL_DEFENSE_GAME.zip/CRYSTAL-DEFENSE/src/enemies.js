import { CONFIG } from './config.js';
import { PhysicsEngine } from './collision.js';
import { Projectile } from './projectiles.js';
export class Enemy {
        constructor(type, x, y, waveScale = 1) {
            this.uid = ENEMY_UID_COUNTER++;
            this.type = type;
            const cfg = CONFIG.ENEMY_TYPES[type];
            this.name = cfg.name;
            this.x = x;
            this.y = y;
            this.radius = cfg.radius;
            this.maxHp = Math.round(cfg.hp * waveScale);
            this.hp = this.maxHp;
            this.speed = cfg.speed * (1 + Math.min(0.25, (waveScale - 1) * 0.15));
            this.damage = cfg.damage;
            this.attackRate = cfg.attackRate || 1.0;
            this.attackCooldown = 0;
            this.reward = cfg.reward;
            this.score = cfg.score;
            this.color = cfg.color;
            this.armor = cfg.armor || 1.0;
            this.detectRange = cfg.detectRange || 340;
            this.ranged = !!cfg.ranged;
            this.shootRange = cfg.shootRange || 0;
            this.preferredDist = cfg.preferredDist || 0;
            this.explosionRadius = cfg.explosionRadius || 0;
            this.fuseTime = cfg.fuseTime || 0.85;
            this.primed = false;
            this.fuseTimer = 0;

            this.angle = 0;
            this.animTime = Math.random() * 10;
            this.hitFlash = 0;
            this.dead = false;
        }

        takeDamage(amount, game) {
            if (this.dead) return;
            const actual = amount * this.armor;
            this.hp -= actual;
            this.hitFlash = 0.12;
            game.particles.spawnDamageText(this.x, this.y - this.radius, Math.round(actual), '#F8FAFC');

            if (this.hp <= 0) {
                this.die(game);
            }
        }

        die(game) {
            if (this.dead) return;
            this.dead = true;
            game.player.money += this.reward;
            game.player.score += this.score;
            game.player.kills += 1;

            const bloodColor = this.type === 'robot' ? 'rgba(15, 23, 42, 0.75)' : 'rgba(132, 204, 22, 0.35)';
            game.world.addBloodDecal(this.x, this.y, bloodColor, this.radius * 1.1);
            game.particles.spawnBurst(this.x, this.y, this.color, 12, 170);
        }

        update(dt, game) {
            if (this.dead) return;
            this.animTime += dt * 7;
            if (this.hitFlash > 0) this.hitFlash -= dt;
            if (this.attackCooldown > 0) this.attackCooldown -= dt;

            // Target selection: Default to Crystal, switch to Player if within detection range
            const distPlayer = Math.hypot(game.player.x - this.x, game.player.y - this.y);
            const distCrystal = Math.hypot(game.crystal.x - this.x, game.crystal.y - this.y);

            let target = game.crystal;
            let targetDist = distCrystal;
            if (distPlayer <= this.detectRange && distPlayer < distCrystal + 90) {
                target = game.player;
                targetDist = distPlayer;
            }

            // Explosive Mutant Fuse Logic
            if (this.type === 'explosive') {
                if (this.primed) {
                    this.fuseTimer -= dt;
                    if (this.fuseTimer <= 0) {
                        this.detonate(game);
                    }
                    return;
                } else if (targetDist <= this.radius + target.radius + 36) {
                    this.primed = true;
                    this.fuseTimer = this.fuseTime;
                    return;
                }
            }

            // Ranged Robot AI
            if (this.ranged) {
                const steer = PhysicsEngine.computeSteeringDirection(this, target.x, target.y, game.world.obstacles, game.enemies);
                this.angle = Math.atan2(target.y - this.y, target.x - this.x);

                if (targetDist > this.shootRange) {
                    this.x += steer.x * this.speed * dt;
                    this.y += steer.y * this.speed * dt;
                } else if (targetDist < this.preferredDist * 0.7) {
                    // Back away slightly to keep tactical distance
                    this.x -= steer.x * (this.speed * 0.6) * dt;
                    this.y -= steer.y * (this.speed * 0.6) * dt;
                }

                if (targetDist <= this.shootRange && this.attackCooldown <= 0) {
                    this.attackCooldown = this.attackRate;
                    game.audio.playRobotLaser();
                    game.projectiles.push(new Projectile({
                        x: this.x + Math.cos(this.angle) * 22,
                        y: this.y + Math.sin(this.angle) * 22,
                        vx: Math.cos(this.angle) * 520,
                        vy: Math.sin(this.angle) * 520,
                        speed: 520,
                        damage: this.damage,
                        color: '#EF4444',
                        radius: 4.5,
                        fromPlayer: false,
                        maxDist: 650
                    }));
                }

                PhysicsEngine.resolveCircleObstacle(this, game.world.obstacles);
                return;
            }

            // Melee Zombie Movement & Attack
            const reach = this.radius + target.radius + 6;
            if (targetDist > reach) {
                const steer = PhysicsEngine.computeSteeringDirection(this, target.x, target.y, game.world.obstacles, game.enemies);
                this.x += steer.x * this.speed * dt;
                this.y += steer.y * this.speed * dt;
                this.angle = steer.angle;
            } else {
                this.angle = Math.atan2(target.y - this.y, target.x - this.x);
                if (this.attackCooldown <= 0) {
                    this.attackCooldown = this.attackRate;
                    game.audio.playZombieAttack();
                    target.takeDamage(this.damage, game);
                }
            }

            PhysicsEngine.resolveCircleObstacle(this, game.world.obstacles);
        }

        detonate(game) {
            if (this.dead) return;
            this.dead = true;
            game.audio.playExplosion();
            game.camera.shake(10, 0.3);
            game.particles.spawnExplosion(this.x, this.y, '#F97316', this.explosionRadius);

            // Damage each entity inside blast radius at most ONCE
            if (Math.hypot(game.player.x - this.x, game.player.y - this.y) <= this.explosionRadius + game.player.radius) {
                game.player.takeDamage(this.damage, game);
            }
            if (Math.hypot(game.crystal.x - this.x, game.crystal.y - this.y) <= this.explosionRadius + game.crystal.radius) {
                game.crystal.takeDamage(this.damage, game);
            }
        }

        draw(ctx, showHazards = true) {
            // Draw Explosive Mutant Hazard Ring if primed
            if (this.type === 'explosive' && this.primed && showHazards) {
                const progress = 1 - (this.fuseTimer / this.fuseTime);
                ctx.save();
                ctx.fillStyle = `rgba(249, 115, 22, ${0.15 + progress * 0.25})`;
                ctx.strokeStyle = '#EF4444';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.explosionRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                ctx.restore();
            }

            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            const sway = Math.sin(this.animTime) * 3;

            if (this.type === 'robot') {
                // Assault Robot Chassis
                ctx.fillStyle = this.hitFlash > 0 ? '#FFFFFF' : '#1E293B';
                ctx.strokeStyle = '#38BDF8';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.roundRect(-16, -16, 32, 32, 6);
                ctx.fill();
                ctx.stroke();

                // Shoulder Laser Cannon
                ctx.fillStyle = '#475569';
                ctx.fillRect(4, 10, 18, 6);

                // Glowing Red Optic Scanner
                ctx.fillStyle = '#EF4444';
                ctx.fillRect(6, -8, 6, 16);
            } else {
                // Detailed Zombie / Mutant Anatomy
                ctx.fillStyle = this.hitFlash > 0 ? '#FFFFFF' : this.color;
                ctx.strokeStyle = '#1A2E05';
                ctx.lineWidth = 2;

                // Outstretched Clawing Arms
                ctx.fillRect(4, -this.radius + 2 + sway, this.radius * 0.95, 6);
                ctx.fillRect(4, this.radius - 8 - sway, this.radius * 0.95, 6);

                // Shoulders & Torso
                ctx.beginPath();
                ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Heavy Brute Armor Plates or Explosive Sacs
                if (this.type === 'heavy') {
                    ctx.fillStyle = '#334155';
                    ctx.fillRect(-14, -18, 22, 36);
                } else if (this.type === 'explosive') {
                    ctx.fillStyle = '#FB923C';
                    ctx.beginPath();
                    ctx.arc(-6, -8, 7, 0, Math.PI * 2);
                    ctx.arc(-6, 8, 7, 0, Math.PI * 2);
                    ctx.fill();
                }

                // Zombie Head & Glowing Eyes
                ctx.fillStyle = '#365314';
                ctx.beginPath();
                ctx.arc(2, 0, this.radius * 0.55, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = this.type === 'fast' ? '#FACC15' : '#EF4444';
                ctx.fillRect(6, -5, 4, 3);
                ctx.fillRect(6, 2, 4, 3);
            }

            ctx.restore();

            // Health bar if damaged
            if (this.hp < this.maxHp) {
                const bw = this.radius * 2;
                ctx.fillStyle = 'rgba(0,0,0,0.75)';
                ctx.fillRect(this.x - bw / 2, this.y - this.radius - 11, bw, 4);
                ctx.fillStyle = '#EF4444';
                ctx.fillRect(this.x - bw / 2, this.y - this.radius - 11, bw * (this.hp / this.maxHp), 4);
            }
        }
    }
