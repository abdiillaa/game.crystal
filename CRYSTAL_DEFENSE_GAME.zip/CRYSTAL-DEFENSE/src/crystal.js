import { CONFIG } from './config.js';
export class EnergyCrystal {
        constructor() {
            this.x = CONFIG.CRYSTAL_X;
            this.y = CONFIG.CRYSTAL_Y;
            this.radius = 44;
            this.maxHp = CONFIG.CRYSTAL_INITIAL_HP;
            this.hp = this.maxHp;
            this.hitFlash = 0;
            this.rotAngle = 0;
            this.orbitParticles = [];
            for (let i = 0; i < 14; i++) {
                this.orbitParticles.push({
                    angle: (Math.PI * 2 * i) / 14,
                    dist: 56 + (i % 3) * 14,
                    speed: 1.2 + (i % 4) * 0.35
                });
            }
        }

        takeDamage(amount, game) {
            if (this.hp <= 0) return;
            this.hp = Math.max(0, this.hp - amount);
            this.hitFlash = 0.25;
            game.audio.playCrystalHit();
            game.camera.shake(7, 0.2);
            game.particles.spawnBurst(this.x, this.y, '#00F0FF', 10, 160);

            if (this.hp <= 0) {
                game.particles.spawnExplosion(this.x, this.y, '#00F0FF', 55);
                game.triggerGameOver(false, 'Энергия Кристалы толықтай қирады!');
            }
        }

        repair(amount) {
            const before = this.hp;
            this.hp = Math.min(this.maxHp, this.hp + amount);
            return this.hp - before;
        }

        update(dt) {
            this.rotAngle += dt * 0.9;
            if (this.hitFlash > 0) this.hitFlash -= dt;
            for (const p of this.orbitParticles) {
                p.angle += p.speed * dt;
            }
        }

        getCoreColor() {
            const ratio = this.hp / this.maxHp;
            if (ratio > 0.55) return { main: '#00F0FF', glow: 'rgba(0, 240, 255, 0.45)', ring: '#38BDF8' };
            if (ratio > 0.25) return { main: '#F59E0B', glow: 'rgba(245, 158, 11, 0.45)', ring: '#FBBF24' };
            return { main: '#EF4444', glow: 'rgba(239, 68, 68, 0.55)', ring: '#F87171' };
        }

        draw(ctx) {
            const colors = this.getCoreColor();
            ctx.save();
            ctx.translate(this.x, this.y);

            // Outer Energy Forcefield Dome
            const grad = ctx.createRadialGradient(0, 0, 10, 0, 0, 110);
            grad.addColorStop(0, colors.glow);
            grad.addColorStop(0.65, 'rgba(168, 85, 247, 0.12)');
            grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(0, 0, 110, 0, Math.PI * 2);
            ctx.fill();

            // Protective Shield Circle
            ctx.strokeStyle = this.hitFlash > 0 ? '#FFFFFF' : colors.ring;
            ctx.lineWidth = 2.5;
            ctx.setLineDash([14, 8]);
            ctx.beginPath();
            ctx.arc(0, 0, 74, this.rotAngle, this.rotAngle + Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);

            // Metallic Pedestal Base
            ctx.fillStyle = '#0F172A';
            ctx.strokeStyle = '#475569';
            ctx.lineWidth = 3;
            ctx.beginPath();
            for (let i = 0; i < 8; i++) {
                const a = (Math.PI * 2 * i) / 8;
                const px = Math.cos(a) * 48;
                const py = Math.sin(a) * 48;
                if (i === 0) ctx.moveTo(px, py);
                else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Rotating Crystal Hexagonal Shard
            ctx.save();
            ctx.rotate(this.rotAngle);
            ctx.fillStyle = this.hitFlash > 0 ? '#FFFFFF' : colors.main;
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 2;
            ctx.beginPath();
            for (let i = 0; i < 6; i++) {
                const a = (Math.PI * 2 * i) / 6;
                const r = i % 2 === 0 ? 34 : 26;
                const px = Math.cos(a) * r;
                const py = Math.sin(a) * r;
                if (i === 0) ctx.moveTo(px, py);
                else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();

            // Orbiting Energy Particles
            for (const p of this.orbitParticles) {
                const px = Math.cos(p.angle) * p.dist;
                const py = Math.sin(p.angle) * p.dist;
                ctx.fillStyle = colors.main;
                ctx.beginPath();
                ctx.arc(px, py, 3, 0, Math.PI * 2);
                ctx.fill();
            }

            ctx.restore();

            // World-space Crystal HP Bar right above the Crystal
            const barW = 96;
            const barH = 7;
            const bx = this.x - barW / 2;
            const by = this.y - 68;
            ctx.fillStyle = 'rgba(8, 11, 17, 0.85)';
            ctx.fillRect(bx - 1, by - 1, barW + 2, barH + 2);
            ctx.fillStyle = colors.main;
            ctx.fillRect(bx, by, barW * (this.hp / this.maxHp), barH);
        }
    }
