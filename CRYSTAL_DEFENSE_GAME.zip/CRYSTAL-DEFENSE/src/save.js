import { CONFIG } from './config.js';
export class SaveManager {
        constructor() {
            this.defaultData = {
                bestWave: 1,
                highScore: 0,
                totalKills: 0,
                victories: 0,
                settings: {
                    sfxVolume: 80,
                    musicVolume: 50,
                    touchControls: false,
                    hazardIndicators: true
                },
                activeRun: null
            };
            this.data = this.load();
        }

        load() {
            try {
                const raw = localStorage.getItem(CONFIG.STORAGE_KEY);
                if (!raw) return JSON.parse(JSON.stringify(this.defaultData));
                const parsed = JSON.parse(raw);
                return {
                    ...this.defaultData,
                    ...parsed,
                    settings: { ...this.defaultData.settings, ...(parsed.settings || {}) }
                };
            } catch (e) {
                return JSON.parse(JSON.stringify(this.defaultData));
            }
        }

        save() {
            try {
                localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(this.data));
                return true;
            } catch (e) {
                return false;
            }
        }

        saveActiveRun(gameState) {
            this.data.activeRun = gameState;
            if (gameState.wave > this.data.bestWave) {
                this.data.bestWave = gameState.wave;
            }
            if (gameState.score > this.data.highScore) {
                this.data.highScore = gameState.score;
            }
            this.save();
        }

        clearActiveRun() {
            this.data.activeRun = null;
            this.save();
        }

        recordStats(wave, score, kills, won = false) {
            if (wave > this.data.bestWave) this.data.bestWave = wave;
            if (score > this.data.highScore) this.data.highScore = score;
            this.data.totalKills += kills;
            if (won) this.data.victories += 1;
            this.save();
        }
    }
