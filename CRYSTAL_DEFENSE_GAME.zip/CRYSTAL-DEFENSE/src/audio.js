// Web Audio API Synthesizer
export class SoundSystem {
        constructor() {
            this.ctx = null;
            this.sfxVolume = 0.8;
            this.musicVolume = 0.5;
            this.initialized = false;
        }

        init() {
            if (this.initialized) return;
            try {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (AudioCtx) {
                    this.ctx = new AudioCtx();
                    this.initialized = true;
                }
            } catch (e) {
                console.warn('Web Audio API unavailable, running silently.');
            }
        }

        resume() {
            if (!this.initialized) this.init();
            if (this.ctx && this.ctx.state === 'suspended') {
                this.ctx.resume().catch(() => {});
            }
        }

        playTone(freq, endFreq, duration, type = 'sawtooth', gainVal = 0.2) {
            if (!this.ctx || this.sfxVolume <= 0.01) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = type;
                osc.frequency.setValueAtTime(freq, now);
                osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + duration);

                const finalGain = gainVal * this.sfxVolume;
                gain.gain.setValueAtTime(finalGain, now);
                gain.gain.linearRampToValueAtTime(0.001, now + duration);

                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + duration);
            } catch (e) {}
        }

        playNoise(duration, filterFreq = 800, gainVal = 0.25) {
            if (!this.ctx || this.sfxVolume <= 0.01) return;
            try {
                const now = this.ctx.currentTime;
                const bufferSize = Math.floor(this.ctx.sampleRate * duration);
                const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
                const data = buffer.getChannelData(0);
                for (let i = 0; i < bufferSize; i++) {
                    data[i] = Math.random() * 2 - 1;
                }
                const noise = this.ctx.createBufferSource();
                noise.buffer = buffer;

                const filter = this.ctx.createBiquadFilter();
                filter.type = 'lowpass';
                filter.frequency.setValueAtTime(filterFreq, now);

                const gain = this.ctx.createGain();
                gain.gain.setValueAtTime(gainVal * this.sfxVolume, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

                noise.connect(filter);
                filter.connect(gain);
                gain.connect(this.ctx.destination);
                noise.start(now);
            } catch (e) {}
        }

        playShoot(weaponId) {
            this.resume();
            if (weaponId === 'pistol') {
                this.playTone(520, 110, 0.11, 'triangle', 0.22);
                this.playNoise(0.07, 1400, 0.16);
            } else if (weaponId === 'rifle') {
                this.playTone(620, 140, 0.08, 'sawtooth', 0.18);
                this.playNoise(0.06, 1800, 0.15);
            } else if (weaponId === 'shotgun') {
                this.playNoise(0.22, 650, 0.35);
                this.playTone(220, 55, 0.19, 'square', 0.25);
            } else if (weaponId === 'plasma') {
                this.playTone(980, 220, 0.24, 'sine', 0.26);
                this.playTone(490, 880, 0.18, 'sawtooth', 0.15);
            }
        }

        playHit() {
            this.playTone(280, 90, 0.05, 'triangle', 0.12);
        }

        playZombieAttack() {
            this.playTone(150, 65, 0.18, 'sawtooth', 0.2);
        }

        playRobotLaser() {
            this.playTone(740, 290, 0.14, 'square', 0.15);
        }

        playExplosion() {
            this.playNoise(0.45, 380, 0.42);
            this.playTone(110, 30, 0.4, 'sine', 0.32);
        }

        playCrystalHit() {
            this.playTone(880, 440, 0.22, 'sine', 0.22);
        }

        playWaveStart() {
            this.playTone(220, 440, 0.35, 'sawtooth', 0.2);
        }

        playBossSpawn() {
            this.playTone(110, 55, 0.75, 'sawtooth', 0.35);
            setTimeout(() => this.playTone(140, 70, 0.65, 'square', 0.3), 250);
        }

        playShopBuy() {
            this.playTone(523.25, 783.99, 0.16, 'sine', 0.22);
        }

        playReload() {
            this.playTone(320, 480, 0.12, 'triangle', 0.15);
        }

        playVictory() {
            const notes = [523.25, 659.25, 783.99, 1046.5];
            notes.forEach((n, idx) => {
                setTimeout(() => this.playTone(n, n * 1.02, 0.28, 'triangle', 0.25), idx * 140);
            });
        }

        playDefeat() {
            const notes = [392.0, 349.23, 311.13, 261.63];
            notes.forEach((n, idx) => {
                setTimeout(() => this.playTone(n, n * 0.95, 0.35, 'sawtooth', 0.25), idx * 170);
            });
        }
    }
