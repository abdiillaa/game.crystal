export class ShopManager {
        constructor(game) {
            this.game = game;
            this.catalog = [
                {
                    id: 'damage',
                    title: 'Қару Зақымы (+18%)',
                    desc: 'Барлық қарулардың оқ зақымын арттырады.',
                    baseCost: 75,
                    costStep: 55,
                    maxLevel: 5,
                    getLevel: (p) => p.upgrades.damageLevel,
                    apply: (p) => { p.upgrades.damageLevel += 1; }
                },
                {
                    id: 'firerate',
                    title: 'Ату Жылдамдығы (+12%)',
                    desc: 'Барлық қарулардың ату жиілігін жылдамдатады.',
                    baseCost: 80,
                    costStep: 60,
                    maxLevel: 5,
                    getLevel: (p) => p.upgrades.fireRateLevel,
                    apply: (p) => { p.upgrades.fireRateLevel += 1; }
                },
                {
                    id: 'magcap',
                    title: 'Оқ Сыйымдылығы (+20%)',
                    desc: 'Магазиндегі оқ санын көбейтеді.',
                    baseCost: 65,
                    costStep: 45,
                    maxLevel: 5,
                    getLevel: (p) => p.upgrades.magCapacityLevel,
                    apply: (p) => {
                        p.upgrades.magCapacityLevel += 1;
                        p.weapons.forEach(w => { w.clip = p.getEffectiveMagSize(w); });
                    }
                },
                {
                    id: 'speed',
                    title: 'Экзо-Етік (+10% Жылдамдық)',
                    desc: 'Ойыншының қозғалу және жалтару жылдамдығын арттырады.',
                    baseCost: 70,
                    costStep: 50,
                    maxLevel: 4,
                    getLevel: (p) => p.upgrades.speedLevel,
                    apply: (p) => { p.upgrades.speedLevel += 1; }
                },
                {
                    id: 'maxhp',
                    title: 'Максималды HP (+25 HP)',
                    desc: 'Ойыншының максималды денсаулығын өсіріп, емдейді.',
                    baseCost: 85,
                    costStep: 55,
                    maxLevel: 4,
                    getLevel: (p) => p.upgrades.maxHpLevel,
                    apply: (p) => {
                        p.upgrades.maxHpLevel += 1;
                        p.maxHp += 25;
                        p.hp = p.maxHp;
                    }
                },
                {
                    id: 'repair_crystal',
                    title: 'Кристалды Жөндеу (+250 HP)',
                    desc: 'Энергия кристалының HP-ын қалпына келтіреді.',
                    baseCost: 90,
                    costStep: 0,
                    isConsumable: true,
                    canBuy: (g) => g.crystal.hp < g.crystal.maxHp,
                    apply: (p, g) => { g.crystal.repair(250); }
                },
                {
                    id: 'ammo_pack',
                    title: 'Қосалқы Оқ Қоры (+100%)',
                    desc: 'Автомат, Дробовик және Плазма оқтарын толтырады.',
                    baseCost: 55,
                    costStep: 0,
                    isConsumable: true,
                    canBuy: () => true,
                    apply: (p) => {
                        p.weapons.forEach(w => {
                            if (!w.infiniteReserve) w.reserve = w.reserveMax;
                            w.clip = p.getEffectiveMagSize(w);
                        });
                    }
                },
                {
                    id: 'shield_pack',
                    title: 'Энергия Қалқаны (+100 Shield)',
                    desc: 'Ойыншының қорғаныс қалқанын 100%-ға толтырады.',
                    baseCost: 75,
                    costStep: 0,
                    isConsumable: true,
                    canBuy: (g) => g.player.shield < g.player.maxShield,
                    apply: (p) => { p.shield = p.maxShield; }
                }
            ];
        }

        getItemCost(item) {
            if (item.isConsumable) return item.baseCost;
            const lvl = item.getLevel(this.game.player);
            return item.baseCost + lvl * item.costStep;
        }

        buyItem(itemId) {
            const item = this.catalog.find(i => i.id === itemId);
            if (!item) return false;
            const p = this.game.player;
            const cost = this.getItemCost(item);

            if (p.money < cost) {
                this.game.ui.showToast('Ақша жеткіліксіз!');
                return false;
            }

            if (!item.isConsumable) {
                const lvl = item.getLevel(p);
                if (lvl >= item.maxLevel) return false;
            } else if (item.canBuy && !item.canBuy(this.game)) {
                this.game.ui.showToast('Бұл параметр қазірдің өзінде толық!');
                return false;
            }

            p.money -= cost;
            item.apply(p, this.game);
            this.game.audio.playShopBuy();
            this.renderShop();
            this.game.ui.updateHud();
            return true;
        }

        renderShop() {
            const grid = document.getElementById('shopItemsGrid');
            const moneyEl = document.getElementById('shopMoneyDisplay');
            const p = this.game.player;
            moneyEl.textContent = `$${p.money}`;
            grid.innerHTML = '';

            for (const item of this.catalog) {
                const cost = this.getItemCost(item);
                const isMax = !item.isConsumable && item.getLevel(p) >= item.maxLevel;
                const canUse = item.isConsumable ? item.canBuy(this.game) : !isMax;
                const canAfford = p.money >= cost && canUse;
                const lvlText = item.isConsumable ? 'БІР РЕТТІК' : `ДЕҢГЕЙ ${item.getLevel(p)} / ${item.maxLevel}`;

                const card = document.createElement('div');
                card.className = 'bg-slate-900/95 border border-slate-700/80 rounded-xl p-4 flex flex-col justify-between';
                card.innerHTML = `
                    <div>
                        <div class="flex justify-between items-center text-[11px] font-mono-num text-cyan-400 mb-1">
                            <span>${lvlText}</span>
                            <span class="text-amber-400 font-bold">$${cost}</span>
                        </div>
                        <div class="font-display font-bold text-sm text-white mb-1">${item.title}</div>
                        <p class="text-xs text-slate-400 leading-relaxed mb-3">${item.desc}</p>
                    </div>
                    <button ${canAfford ? '' : 'disabled'} data-buy="${item.id}"
                        class="chamfer-btn w-full py-2 px-3 font-display font-bold text-xs ${
                            isMax ? 'bg-slate-800 text-emerald-400' :
                            canAfford ? 'bg-amber-500 hover:bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-500'
                        }">
                        ${isMax ? '✓ МАКСИМУМ' : `САТЫП АЛУ ($${cost})`}
                    </button>
                `;
                card.querySelector('button').addEventListener('click', () => this.buyItem(item.id));
                grid.appendChild(card);
            }
        }
    }
