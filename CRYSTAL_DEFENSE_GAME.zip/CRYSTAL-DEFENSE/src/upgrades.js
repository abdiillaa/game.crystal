export const UPGRADE_TIERS = { maxDamageLevel: 5, maxFireRateLevel: 5, maxMagLevel: 5, maxSpeedLevel: 4, maxHpLevel: 4 };
