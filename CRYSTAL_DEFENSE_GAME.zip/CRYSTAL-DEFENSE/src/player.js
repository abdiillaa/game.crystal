import { CONFIG } from './config.js';
import { PhysicsEngine } from './collision.js';
import { Projectile } from './projectiles.js';
export class Player {
        constructor() {
            this.x = CONFIG.CRYSTAL_X;
            this.y = CONFIG.CRYSTAL_Y + 135;
            this.radius = 20;
            this.angle = 0;
            this.maxHp = CONFIG.PLAYER_INITIAL_HP;
            this.hp = this.maxHp;
            this.shield = 0;
            this.maxShield = 100;
            this.stamina = 100;
            this.maxStamina = 100;
            this.money = 0;
            this.score = 0;
            this.kills = 0;
            this.walkCycle = 0;
            this.muzzleFlash = 0;

            // Upgrade multipliers
            this.upgrades = {
                damageLevel: 0,
                fireRateLevel: 0,
                magCapacityLevel: 0,
                speedLevel: 0,
                maxHpLevel: 0
            };

            // Initialize weapons inventory
            this.weapons = CONFIG.WEAPONS.map(w => ({
                ...w,
                clip: w.magSize,
                reserve: w.infiniteReserve ? 9999 : Math.floor(w.reserveMax * 0.65)
            }));
            this.currentWeaponIndex = 0;
            this.fireCooldown = 0;
            this.reloading = false;
            this.reloadTimer = 0;
            this.reloadDuration = 1.0;
        }

        get currentWeapon() {
            return this.weapons[this.currentWeaponIndex];
        }

        getEffectiveMagSize(w) {
            return Math.round(w.magSize * (1 + this.upgrades.magCapacityLevel * 0.2));
        }

        getEffectiveDamage(w) {
            return w.damage * (1 + this.upgrades.damageLevel * 0.18);
        }

        getEffectiveFireRate(w) {
            return w.fireRate * Math.pow(0.88, this.upgrades.fireRateLevel);
        }

        switchWeapon(idx) {
            if (idx < 0 || idx >= this.weapons.length || idx === this.currentWeaponIndex) return;
            this.currentWeaponIndex = idx;
            this.reloading = false;
            this.reloadTimer = 0;
        }

        startReload() {
            const w = this.currentWeapon;
            const maxMag = this.getEffectiveMagSize(w);
            if (this.reloading || w.clip >= maxMag) return;
            if (!w.infiniteReserve && w.reserve <= 0) return;

            this.reloading = true;
            this.reloadDuration = w.reloadTime;
            this.reloadTimer = w.reloadTime;
            if (window.gameInstance) window.gameInstance.audio.playReload();
        }

        finishReload() {
            const w = this.currentWeapon;
            const maxMag = this.getEffectiveMagSize(w);
            const needed = maxMag - w.clip;
            if (w.infiniteReserve) {
                w.clip = maxMag;
            } else {
                const take = Math.min(needed, w.reserve);
                w.clip += take;
                w.reserve -= take;
            }
            this.reloading = false;
            this.reloadTimer = 0;
        }

        takeDamage(amount, game) {
            if (this.hp <= 0) return;
            let remaining = amount;
            if (this.shield > 0) {
                const absorbed = Math.min(this.shield, remaining);
                this.shield -= absorbed;
                remaining -= absorbed;
            }
            if (remaining > 0) {
                this.hp = Math.max(0, this.hp - remaining);
                const vig = document.getElementById('damageVignette');
                vig.style.opacity = '1';
                setTimeout(() => { vig.style.opacity = '0'; }, 160);
                game.camera.shake(6, 0.18);
            }

            if (this.hp <= 0) {
                game.particles.spawnExplosion(this.x, this.y, '#EF4444', 45);
                game.triggerGameOver(false, 'Қорғаушы шайқаста қаза тапты!');
            }
        }

        update(dt, game) {
            if (this.hp <= 0) return;

            const move = game.input.getMoveVector();
            const isMoving = Math.hypot(move.x, move.y) > 0.05;

            let speed = CONFIG.PLAYER_BASE_SPEED * (1 + this.upgrades.speedLevel * 0.1);
            if (game.input.isSprinting() && isMoving && this.stamina > 2) {
                speed *= CONFIG.PLAYER_SPRINT_MULT;
                this.stamina = Math.max(0, this.stamina - 34 * dt);
            } else {
                this.stamina = Math.min(this.maxStamina, this.stamina + 22 * dt);
            }

            this.x += move.x * speed * dt;
            this.y += move.y * speed * dt;

            if (isMoving) {
                this.walkCycle += dt * 10;
            }

            // Prevent walking through walls or directly inside the Crystal pedestal
            PhysicsEngine.resolveCircleObstacle(this, game.world.obstacles);
            const dxC = this.x - game.crystal.x;
            const dyC = this.y - game.crystal.y;
            const distC = Math.hypot(dxC, dyC);
            const minC = this.radius + game.crystal.radius;
            if (distC < minC && distC > 0) {
                this.x += (dxC / distC) * (minC - distC);
                this.y += (dyC / distC) * (minC - distC);
            }

            // Aim towards mouse or right virtual joystick
            if (game.input.joyAim.active && Math.hypot(game.input.joyAim.dx, game.input.joyAim.dy) > 0.15) {
                this.angle = Math.atan2(game.input.joyAim.dy, game.input.joyAim.dx);
            } else {
                const worldMouseX = game.input.mouse.x + game.camera.x;
                const worldMouseY = game.input.mouse.y + game.camera.y;
                this.angle = Math.atan2(worldMouseY - this.y, worldMouseX - this.x);
            }

            // Reload timer progression
            if (this.reloading) {
                this.reloadTimer -= dt;
                if (this.reloadTimer <= 0) {
                    this.finishReload();
                }
            }

            if (this.fireCooldown > 0) this.fireCooldown -= dt;
            if (this.muzzleFlash > 0) this.muzzleFlash -= dt;

            // Continuous Firing
            if (game.input.isFiring() && !this.reloading && this.fireCooldown <= 0) {
                this.fireWeapon(game);
            }
        }

        fireWeapon(game) {
            const w = this.currentWeapon;
            if (w.clip <= 0) {
                this.startReload();
                return;
            }

            w.clip -= 1;
            this.fireCooldown = this.getEffectiveFireRate(w);
            this.muzzleFlash = 0.06;
            game.audio.playShoot(w.id);

            const barrelLen = 28;
            const spawnX = this.x + Math.cos(this.angle) * barrelLen;
            const spawnY = this.y + Math.sin(this.angle) * barrelLen;
            const baseDmg = this.getEffectiveDamage(w);

            for (let i = 0; i < w.pellets; i++) {
                const spreadOffset = (Math.random() - 0.5) * w.spread;
                const shotAngle = this.angle + spreadOffset;
                game.projectiles.push(new Projectile({
                    x: spawnX,
                    y: spawnY,
                    vx: Math.cos(shotAngle) * w.bulletSpeed,
                    vy: Math.sin(shotAngle) * w.bulletSpeed,
                    speed: w.bulletSpeed,
                    damage: baseDmg,
                    color: w.color,
                    radius: w.id === 'plasma' ? 6 : 4,
                    fromPlayer: true,
                    pierce: w.pierce,
                    robotBonus: w.robotBonus,
                    explosiveRadius: w.explosiveRadius || 0,
                    falloff: !!w.falloff,
                    maxDist: w.range
                }));
            }

            if (w.clip <= 0) {
                this.startReload();
            }
        }

        draw(ctx) {
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            // Tactical Laser Sight Line
            ctx.strokeStyle = 'rgba(0, 240, 255, 0.14)';
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(22, 0);
            ctx.lineTo(260, 0);
            ctx.stroke();

            // Shield Aura if active
            if (this.shield > 0) {
                ctx.strokeStyle = 'rgba(0, 240, 255, 0.65)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(0, 0, this.radius + 5, 0, Math.PI * 2);
                ctx.stroke();
            }

            // Walking feet animation
            const footOffset = Math.sin(this.walkCycle) * 5;
            ctx.fillStyle = '#0F172A';
            ctx.fillRect(-6 + footOffset, -14, 10, 6);
            ctx.fillRect(-6 - footOffset, 8, 10, 6);

            // Armored Shoulders & Torso
            ctx.fillStyle = '#1E293B';
            ctx.strokeStyle = '#38BDF8';
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.roundRect(-14, -16, 26, 32, 8);
            ctx.fill();
            ctx.stroke();

            // Arms holding weapon
            ctx.fillStyle = '#334155';
            ctx.fillRect(4, -11, 16, 6);
            ctx.fillRect(4, 5, 16, 6);

            // Distinct Weapon Model
            const wid = this.currentWeapon.id;
            if (wid === 'pistol') {
                ctx.fillStyle = '#94A3B8';
                ctx.fillRect(14, -3, 14, 6);
            } else if (wid === 'rifle') {
                ctx.fillStyle = '#475569';
                ctx.fillRect(10, -4, 24, 8);
                ctx.fillStyle = '#38BDF8';
                ctx.fillRect(16, -2, 10, 4);
            } else if (wid === 'shotgun') {
                ctx.fillStyle = '#78350F';
                ctx.fillRect(8, -5, 14, 10);
                ctx.fillStyle = '#D97706';
                ctx.fillRect(20, -4, 14, 8);
            } else if (wid === 'plasma') {
                ctx.fillStyle = '#4C1D95';
                ctx.fillRect(8, -6, 26, 12);
                ctx.fillStyle = '#A855F7';
                ctx.fillRect(14, -3, 16, 6);
            }

            // Muzzle Flash
            if (this.muzzleFlash > 0) {
                ctx.fillStyle = this.currentWeapon.color;
                ctx.beginPath();
                ctx.arc(34, 0, 9, 0, Math.PI * 2);
                ctx.fill();
            }

            // Tactical Helmet & Glowing Visor
            ctx.fillStyle = '#0F172A';
            ctx.beginPath();
            ctx.arc(0, 0, 12, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#00F0FF';
            ctx.beginPath();
            ctx.roundRect(4, -7, 7, 14, 3);
            ctx.fill();

            ctx.restore();
        }
    }
