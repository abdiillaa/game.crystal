# CRYSTAL DEFENSE: ZOMBIE APOCALYPSE

Толыққанды 2D Top-Down Shooter + Survival + Base Defense браузерлік ойыны.

## 1. WINDOWS КОМПЬЮТЕРІНДЕ ІСКЕ ҚОСУ НҰСҚАУЛЫҒЫ

1. `CRYSTAL_DEFENSE_GAME.zip` архивін кез келген қалтаға шығарып алыңыз (Extract All).
2. **Ең оңай жолы:** `index.html` файлын екі рет басып, кез келген заманауи браузерде (Chrome, Edge, Firefox) тікелей ашыңыз (интернетсіз де толық жұмыс істейді).
3. **Жергілікті сервер арқылы іске қосу (қалауыңызша):**
   - VS Code Live Server кеңейтімі арқылы `index.html` файлын ашу;
   - Немесе терминалда: `python -m http.server 8080` командасын жазып, браузерден `http://localhost:8080` мекенжайын ашу.

## 2. БАСҚАРУ БАТЫРМАЛАРЫ (КОМПЬЮТЕР ЖӘНЕ МОБИЛЬДІ)

- **W, A, S, D** — Ойыншыны қозғалту
- **Тінтуір (Mouse)** — Көздеу
- **Тінтуірдің сол жақ батырмасы** — Үздіксіз оқ ату
- **Shift** — Қысқа уақытқа жылдам жүгіру (Sprint)
- **R** — Қаруды қайта оқтау
- **1, 2, 3, 4** — Қару түрлерін ауыстыру (Пистолет, Автомат, Дробовик, Плазма)
- **E** — Дүкенді (Арсенал) ашу
- **ESC** — Пауза мәзірі

## 3. ЖОБАНЫҢ ФАЙЛДЫҚ ҚҰРЫЛЫМЫ

```
CRYSTAL-DEFENSE/
├── index.html
├── style.css
├── README.md
├── manifest.json
├── src/
│   ├── main.js
│   ├── config.js
│   ├── game.js
│   ├── input.js
│   ├── camera.js
│   ├── world.js
│   ├── collision.js
│   ├── pathfinding.js
│   ├── player.js
│   ├── enemies.js
│   ├── enemy-ai.js
│   ├── projectiles.js
│   ├── weapons.js
│   ├── waves.js
│   ├── boss.js
│   ├── crystal.js
│   ├── shop.js
│   ├── upgrades.js
│   ├── particles.js
│   ├── audio.js
│   ├── ui.js
│   └── save.js
├── assets/
│   ├── sprites/crystal-icon.svg
│   └── audio/README_AUDIO.txt
└── tests/
    └── game.test.js
```

## 4. САҚТАУ ЖҮЙЕСІ

Ойын `localStorage` арқылы ең жоғары жеткен толқынды, рекордтық ұпайды, жалпы жеңілген жаулар санын, баптауларды және ағымдағы науқан прогресін (`CONTINUE` батырмасы үшін) автоматты түрде сақтайды.
