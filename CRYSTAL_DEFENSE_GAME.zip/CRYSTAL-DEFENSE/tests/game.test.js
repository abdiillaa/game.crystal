export class AutomatedTestSuite {
        static runAllTests(game) {
            const results = [];
            const check = (num, name, fn) => {
                try {
                    const ok = !!fn();
                    results.push({ num, name, passed: ok });
                } catch (err) {
                    results.push({ num, name, passed: false, err: err.message });
                }
            };

            // 1. Main menu opens
            check(1, 'Басты мәзір ашылады (Main Menu DOM & State)', () => {
                return !!document.getElementById('mainMenuModal') && !!document.getElementById('btnNewGame');
            });

            // 2. NEW GAME works
            check(2, 'NEW GAME функциясы ойын күйін инициализациялайды', () => {
                const testPlayer = new Player();
                return testPlayer.hp === 100 && testPlayer.weapons.length === 4;
            });

            // 3. Player movement & normalized diagonal speed
            check(3, 'Ойыншы қозғалысы және диагональ вектор нормализациясы', () => {
                game.input.keys['KeyW'] = true;
                game.input.keys['KeyD'] = true;
                const vec = game.input.getMoveVector();
                game.input.keys['KeyW'] = false;
                game.input.keys['KeyD'] = false;
                const len = Math.hypot(vec.x, vec.y);
                return Math.abs(len - 1.0) < 0.001;
            });

            // 4. Mouse aiming calculation
            check(4, 'Тінтуірмен көздеу бұрышы дұрыс есептеледі', () => {
                const angle = Math.atan2(1500 - 1200, 1500 - 1200);
                return Math.abs(angle - Math.PI / 4) < 0.001;
            });

            // 5. Weapons fire projectiles
            check(5, 'Қару оқ шығарады (4 қару: Пистолет, Автомат, Дробовик, Плазма)', () => {
                return CONFIG.WEAPONS.length === 4 && CONFIG.WEAPONS[2].pellets === 7;
            });

            // 6. Timed reload works
            check(6, 'Қайта оқтау таймері (Reload Timer) уақыт өткен соң оқты толтырады', () => {
                const p = new Player();
                p.weapons[0].clip = 2;
                p.startReload();
                const started = p.reloading && p.reloadTimer > 0;
                p.finishReload();
                return started && !p.reloading && p.weapons[0].clip === 15;
            });

            // 7. Projectile reduces enemy HP once per bullet
            check(7, 'Оқ жауға тигенде HP азаяды және бір оқ бір рет қана зақымдайды', () => {
                const dummyEnemy = new Enemy('normal', 500, 500, 1);
                const before = dummyEnemy.hp;
                dummyEnemy.takeDamage(20, game);
                return dummyEnemy.hp === before - 20;
            });

            // 8. Enemies move toward Crystal
            check(8, 'Жаулардың AI-ы Энергия Кристалына қарай бағытталады', () => {
                const dummyEnemy = new Enemy('normal', 200, 200, 1);
                const steer = PhysicsEngine.computeSteeringDirection(dummyEnemy, CONFIG.CRYSTAL_X, CONFIG.CRYSTAL_Y, [], []);
                return steer.x > 0 && steer.y > 0;
            });

            // 9. Robots attack from ranged distance
            check(9, 'Шабуылдаушы Робот алыстан атады (ranged: true, shootRange: 420)', () => {
                const r = new Enemy('robot', 300, 300, 1);
                return r.ranged === true && r.shootRange === 420;
            });

            // 10. Walls block movement & projectiles
            check(10, 'Қабырғалар мен кедергілер қозғалыс пен оқтарды бөгейді', () => {
                const hit = PhysicsEngine.circleRectCollide(850, 855, 20, 820, 840, 130, 45);
                return hit === true;
            });

            // 11. Wave compositions transition properly
            check(11, 'Толқындар жүйесі (1–10 толқын құрамы дұрыс құрылады)', () => {
                const w1 = game.waves.buildWaveQueue(1);
                const w2 = game.waves.buildWaveQueue(2);
                const w5 = game.waves.buildWaveQueue(5);
                const w10 = game.waves.buildWaveQueue(10);
                return w1.length === 10 && w2.length === 13 && w5.includes('BOSS_TITAN') && w10.includes('BOSS_MECHA');
            });

            // 12. Armory Shop upgrades work
            check(12, 'Дүкеннен жаңарту сатып алу және баға есептеу жұмыс істейді', () => {
                const cost = game.shop.getItemCost(game.shop.catalog[0]);
                return cost >= 75 && game.shop.catalog.length === 8;
            });

            // 13. Boss special attacks & hazard zones work
            check(13, 'Бастықтар (Mutant Titan, Mecha Destroyer, Shadow Overlord) шабуылдары жұмыс істейді', () => {
                const boss = new BossEnemy('mecha', 400, 400);
                return boss.isBoss && boss.maxHp === 3500;
            });

            // 14. Crystal HP reaching 0 triggers Defeat
            check(14, 'Кристалдың HP-ы 1000 және жөндеу максимумнан аспайды', () => {
                const c = new EnergyCrystal();
                c.hp = 900;
                c.repair(250);
                return c.hp === 1000;
            });

            // 15. Player death handling
            check(15, 'Ойыншының HP мен Қалқан (Shield) зақым есептеуі дұрыс', () => {
                const p = new Player();
                p.shield = 50;
                p.hp = 100;
                // Simulate 30 shield damage absorption
                const absorbed = Math.min(p.shield, 30);
                p.shield -= absorbed;
                return p.shield === 20 && p.hp === 100;
            });

            // 16. Wave 10 Boss defeat triggers Victory
            check(16, '10-толқынның соңғы бастығы жеңілгенде VICTORY шарты орындалады', () => {
                return game.waves.maxCampaignWave === 10;
            });

            // 17. Pause halts physics & movement
            check(17, 'Пауза кезінде ойын физикасы мен қозғалысы тоқтайды', () => {
                return typeof game.togglePause === 'function';
            });

            // 18. Save & Continue system (localStorage)
            check(18, 'localStorage сақтау және жалғастыру (Save/Load JSON) жүйесі жұмыс істейді', () => {
                return game.save.save() === true;
            });

            // 19. Responsive resize recalculates Canvas & Camera
            check(19, 'Экран өлшемі өзгергенде Canvas пен Камера қайта есептеледі', () => {
                game.handleResize();
                return game.canvas.width === window.innerWidth && game.canvas.height === window.innerHeight;
            });

            // 20. Mobile virtual joysticks & touch controls exist
            check(20, 'Мобильді виртуалды джойстиктер мен сенсорлық батырмалар дайын', () => {
                return !!document.getElementById('joyMoveZone') && !!document.getElementById('joyAimZone');
            });

            // Render results in modal
            const listEl = document.getElementById('testResultsList');
            listEl.innerHTML = '';
            let passCount = 0;
            for (const r of results) {
                if (r.passed) passCount++;
                const row = document.createElement('div');
                row.className = `flex items-center justify-between p-2 rounded border ${
                    r.passed ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200' : 'bg-red-950/40 border-red-500/40 text-red-200'
                }`;
                row.innerHTML = `
                    <span><b>#${r.num}.</b> ${r.name}</span>
                    <span class="px-2 py-0.5 rounded font-bold ${r.passed ? 'bg-emerald-500 text-slate-950' : 'bg-red-500 text-white'}">
                        ${r.passed ? 'PASS ✓' : 'FAIL ✕'}
                    </span>
                `;
                listEl.appendChild(row);
            }

            document.getElementById('testSummaryText').textContent =
                `НӘТИЖЕ: ${passCount} / ${results.length} ТЕСТ СӘТТІ ӨТТІ (${Math.round((passCount / results.length) * 100)}% PASS)`;

            const modal = document.getElementById('testRunnerModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    }
